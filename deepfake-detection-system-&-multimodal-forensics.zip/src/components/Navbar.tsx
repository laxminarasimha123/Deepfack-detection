import React from 'react';
import { 
  ShieldAlert, 
  Upload, 
  History, 
  FileText, 
  BarChart3, 
  User as UserIcon, 
  LogOut, 
  LogIn, 
  Sliders, 
  Radio, 
  Sparkles,
  Layers
} from 'lucide-react';
import { User, UserRole } from '../types';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  currentUser: User | null;
  onOpenAuthModal: (mode: 'login' | 'register') => void;
  onLogout: () => void;
  onSwitchRole: (role: UserRole) => void;
  onSelectSampleMedia: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  currentUser,
  onOpenAuthModal,
  onLogout,
  onSwitchRole,
  onSelectSampleMedia,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Logo & Brand */}
        <div 
          onClick={() => setCurrentTab('home')}
          className="flex cursor-pointer items-center space-x-3 group"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 p-0.5 shadow-lg shadow-cyan-500/20 group-hover:shadow-cyan-500/40 transition-all">
            <div className="flex h-full w-full items-center justify-center rounded-[10px] bg-slate-950">
              <ShieldAlert className="h-5 w-5 text-cyan-400 group-hover:scale-110 transition-transform" />
            </div>
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-bold tracking-tight text-white sm:text-lg">
                DEEPFAKE<span className="text-cyan-400">WATCH</span>
              </span>
              <span className="hidden rounded bg-cyan-950/80 px-1.5 py-0.5 text-[10px] font-semibold text-cyan-400 ring-1 ring-inset ring-cyan-800/50 sm:inline-block">
                AI FORENSICS v3.7
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              Multimodal Digital Media Verification Platform
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="hidden md:flex items-center space-x-1 lg:space-x-2 text-sm font-medium">
          <button
            id="nav-tab-home"
            onClick={() => setCurrentTab('home')}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center space-x-1.5 ${
              currentTab === 'home'
                ? 'bg-slate-800 text-cyan-400 font-semibold'
                : 'text-slate-300 hover:text-white hover:bg-slate-900'
            }`}
          >
            <span>Overview</span>
          </button>

          <button
            id="nav-tab-dashboard"
            onClick={() => setCurrentTab('dashboard')}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center space-x-1.5 ${
              currentTab === 'dashboard'
                ? 'bg-slate-800 text-cyan-400 font-semibold'
                : 'text-slate-300 hover:text-white hover:bg-slate-900'
            }`}
          >
            <BarChart3 className="h-4 w-4" />
            <span>Dashboard</span>
          </button>

          <button
            id="nav-tab-upload"
            onClick={() => setCurrentTab('upload')}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center space-x-1.5 ${
              currentTab === 'upload'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/25'
                : 'text-cyan-400 hover:bg-cyan-950/40 bg-cyan-950/20 ring-1 ring-cyan-500/30'
            }`}
          >
            <Upload className="h-4 w-4" />
            <span>Analyze Media</span>
          </button>

          <button
            id="nav-tab-history"
            onClick={() => setCurrentTab('history')}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center space-x-1.5 ${
              currentTab === 'history'
                ? 'bg-slate-800 text-cyan-400 font-semibold'
                : 'text-slate-300 hover:text-white hover:bg-slate-900'
            }`}
          >
            <History className="h-4 w-4" />
            <span>Detection History</span>
          </button>

          <button
            id="nav-tab-benchmarks"
            onClick={onSelectSampleMedia}
            className="px-2.5 py-1.5 rounded-lg text-slate-300 hover:text-cyan-300 hover:bg-slate-900 transition-colors flex items-center space-x-1"
            title="Pre-loaded Real vs Deepfake Benchmark Samples"
          >
            <Layers className="h-4 w-4 text-cyan-400" />
            <span className="hidden lg:inline">Benchmarks</span>
          </button>

          {/* Admin Tab visible if admin or for testing */}
          {(currentUser?.role === 'admin' || currentUser?.role === 'investigator') && (
            <button
              id="nav-tab-admin"
              onClick={() => setCurrentTab('admin')}
              className={`px-3 py-1.5 rounded-lg transition-colors flex items-center space-x-1.5 ${
                currentTab === 'admin'
                  ? 'bg-indigo-950 text-indigo-300 ring-1 ring-indigo-500 font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-900'
              }`}
            >
              <Sliders className="h-4 w-4 text-indigo-400" />
              <span>Admin Center</span>
            </button>
          )}
        </nav>

        {/* Right Section: Role Switcher & User Profile */}
        <div className="flex items-center space-x-3">
          
          {/* Quick Role Switcher Pill */}
          {currentUser && (
            <div className="hidden xl:flex items-center rounded-lg bg-slate-900 p-1 border border-slate-800 text-xs">
              <span className="px-2 text-slate-400 text-[10px] font-semibold uppercase tracking-wider">Role:</span>
              <button
                onClick={() => onSwitchRole('general_user')}
                className={`px-2 py-1 rounded transition-colors text-xs ${
                  currentUser.role === 'general_user'
                    ? 'bg-slate-800 text-cyan-300 font-medium'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                General User
              </button>
              <button
                onClick={() => onSwitchRole('investigator')}
                className={`px-2 py-1 rounded transition-colors text-xs ${
                  currentUser.role === 'investigator'
                    ? 'bg-blue-900/80 text-blue-200 font-medium'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Investigator
              </button>
              <button
                onClick={() => onSwitchRole('admin')}
                className={`px-2 py-1 rounded transition-colors text-xs ${
                  currentUser.role === 'admin'
                    ? 'bg-indigo-900/80 text-indigo-200 font-medium'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Admin
              </button>
            </div>
          )}

          {/* Status Indicator */}
          <div className="hidden sm:flex items-center space-x-1.5 rounded-full bg-emerald-950/40 px-2.5 py-1 text-xs text-emerald-400 ring-1 ring-inset ring-emerald-500/30">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="text-[11px] font-mono">Engine Online</span>
          </div>

          {/* User Profile or Login */}
          {currentUser ? (
            <div className="flex items-center space-x-2">
              <div className="flex items-center space-x-2 rounded-lg bg-slate-900/80 border border-slate-800 px-2.5 py-1.5">
                {currentUser.avatar ? (
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    className="h-6 w-6 rounded-full object-cover ring-1 ring-cyan-500/50"
                  />
                ) : (
                  <div className="flex h-6 w-6 items-center justify-center rounded-full bg-cyan-900/60 text-cyan-300 text-xs font-bold">
                    {currentUser.name.charAt(0)}
                  </div>
                )}
                <div className="hidden lg:block text-left">
                  <div className="text-xs font-semibold text-slate-200 leading-none truncate max-w-[120px]">
                    {currentUser.name}
                  </div>
                  <div className="text-[10px] text-cyan-400 capitalize">
                    {currentUser.role.replace('_', ' ')}
                  </div>
                </div>
              </div>
              <button
                onClick={onLogout}
                className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-900 rounded-lg transition-colors"
                title="Log out"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center space-x-2">
              <button
                onClick={() => onOpenAuthModal('login')}
                className="px-3 py-1.5 text-xs font-medium text-slate-200 hover:text-white hover:bg-slate-900 rounded-lg transition-colors"
              >
                Sign In
              </button>
              <button
                onClick={() => onOpenAuthModal('register')}
                className="px-3 py-1.5 text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 rounded-lg transition-colors shadow-sm shadow-cyan-500/20"
              >
                Register
              </button>
            </div>
          )}

        </div>

      </div>

      {/* Mobile navigation bar */}
      <div className="flex md:hidden border-t border-slate-800 bg-slate-950 px-2 py-2 justify-around text-xs">
        <button
          onClick={() => setCurrentTab('home')}
          className={`px-2 py-1 rounded ${currentTab === 'home' ? 'text-cyan-400 font-bold' : 'text-slate-400'}`}
        >
          Overview
        </button>
        <button
          onClick={() => setCurrentTab('dashboard')}
          className={`px-2 py-1 rounded ${currentTab === 'dashboard' ? 'text-cyan-400 font-bold' : 'text-slate-400'}`}
        >
          Dashboard
        </button>
        <button
          onClick={() => setCurrentTab('upload')}
          className={`px-2 py-1 rounded ${currentTab === 'upload' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-cyan-400'}`}
        >
          Analyze
        </button>
        <button
          onClick={() => setCurrentTab('history')}
          className={`px-2 py-1 rounded ${currentTab === 'history' ? 'text-cyan-400 font-bold' : 'text-slate-400'}`}
        >
          History
        </button>
        {currentUser?.role === 'admin' && (
          <button
            onClick={() => setCurrentTab('admin')}
            className={`px-2 py-1 rounded ${currentTab === 'admin' ? 'text-indigo-400 font-bold' : 'text-slate-400'}`}
          >
            Admin
          </button>
        )}
      </div>
    </header>
  );
};
