import React, { useState, useRef } from 'react';
import { 
  UploadCloud, 
  Image as ImageIcon, 
  Film, 
  Mic, 
  Layers, 
  CheckCircle, 
  AlertCircle, 
  FileCheck, 
  FileCode, 
  Sparkles, 
  Play, 
  Square,
  RefreshCw,
  Info,
  ShieldAlert,
  SlidersHorizontal
} from 'lucide-react';
import { BenchmarkSample, MediaType } from '../types';
import { SAMPLE_BENCHMARKS } from '../data/sampleMedia';

interface MediaUploadStudioProps {
  onStartAnalysis: (payload: {
    mediaType: MediaType;
    fileName: string;
    fileSize: number;
    base64Data?: string;
    mimeType?: string;
    benchmarkSampleId?: string;
  }) => void;
  isAnalyzing: boolean;
  selectedBenchmarkSample?: BenchmarkSample | null;
}

export const MediaUploadStudio: React.FC<MediaUploadStudioProps> = ({
  onStartAnalysis,
  isAnalyzing,
  selectedBenchmarkSample,
}) => {
  const [activeModality, setActiveModality] = useState<MediaType>('image');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [base64Data, setBase64Data] = useState<string | null>(null);
  const [fileHash, setFileHash] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [activeBenchmark, setActiveBenchmark] = useState<BenchmarkSample | null>(selectedBenchmarkSample || null);
  const [uploadProgress, setUploadProgress] = useState(100);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Synchronize if selectedBenchmarkSample prop changes
  React.useEffect(() => {
    if (selectedBenchmarkSample) {
      setActiveBenchmark(selectedBenchmarkSample);
      setActiveModality(selectedBenchmarkSample.mediaType);
      setPreviewUrl(selectedBenchmarkSample.thumbnailUrl);
      setSelectedFile(null);
      setBase64Data(null);
      setFileHash('sha256-bench-' + Math.random().toString(16).slice(2, 10));
    }
  }, [selectedBenchmarkSample]);

  // Handle local file selection
  const handleFileChange = (file: File) => {
    setSelectedFile(file);
    setActiveBenchmark(null);
    setUploadProgress(0);

    // Auto-detect modality from mime
    if (file.type.startsWith('image/')) setActiveModality('image');
    else if (file.type.startsWith('video/')) setActiveModality('video');
    else if (file.type.startsWith('audio/')) setActiveModality('audio');

    // Simulate SHA-256 hash
    const fakeHash = 'sha256-' + Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    setFileHash(fakeHash);

    // Read preview & base64
    const reader = new FileReader();
    reader.onprogress = (e) => {
      if (e.lengthComputable) {
        setUploadProgress(Math.round((e.loaded / e.total) * 100));
      }
    };
    reader.onload = () => {
      const result = reader.result as string;
      setBase64Data(result);
      setPreviewUrl(result);
      setUploadProgress(100);
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileChange(e.dataTransfer.files[0]);
    }
  };

  const handleSelectBenchmark = (sample: BenchmarkSample) => {
    setActiveBenchmark(sample);
    setActiveModality(sample.mediaType);
    setPreviewUrl(sample.thumbnailUrl);
    setSelectedFile(null);
    setBase64Data(null);
    setFileHash('sha256-bench-' + Math.random().toString(16).slice(2, 10));
    setUploadProgress(100);
  };

  const handleTriggerAnalysis = () => {
    if (activeBenchmark) {
      onStartAnalysis({
        mediaType: activeBenchmark.mediaType,
        fileName: activeBenchmark.title,
        fileSize: activeBenchmark.fileSize,
        base64Data: activeBenchmark.thumbnailUrl,
        mimeType: activeBenchmark.mediaType === 'video' ? 'video/mp4' : activeBenchmark.mediaType === 'audio' ? 'audio/wav' : 'image/jpeg',
        benchmarkSampleId: activeBenchmark.id,
      });
    } else if (selectedFile) {
      onStartAnalysis({
        mediaType: activeModality,
        fileName: selectedFile.name,
        fileSize: selectedFile.size,
        base64Data: base64Data || undefined,
        mimeType: selectedFile.type,
      });
    }
  };

  const hasMedia = Boolean(selectedFile || activeBenchmark);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      
      {/* Header */}
      <div className="border-b border-slate-800 pb-4">
        <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
          Media Forensic Ingestion Studio
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Upload images, video recordings, audio transcripts, or multimodal feeds for deepfake inspection.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Col: Upload & Config */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Modality Selector Tabs */}
          <div>
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block mb-2">
              1. Select Forensic Modality
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => setActiveModality('image')}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border text-xs font-semibold transition-all ${
                  activeModality === 'image'
                    ? 'border-cyan-500 bg-cyan-950/40 text-cyan-300 shadow-md shadow-cyan-500/10'
                    : 'border-slate-800 bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <ImageIcon className="h-5 w-5 mb-1 text-cyan-400" />
                <span>Image Forensics</span>
                <span className="text-[10px] text-slate-500 font-normal">JPG, PNG, WEBP</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveModality('video')}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border text-xs font-semibold transition-all ${
                  activeModality === 'video'
                    ? 'border-blue-500 bg-blue-950/40 text-blue-300 shadow-md shadow-blue-500/10'
                    : 'border-slate-800 bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Film className="h-5 w-5 mb-1 text-blue-400" />
                <span>Video Forensics</span>
                <span className="text-[10px] text-slate-500 font-normal">MP4, MOV, AVI</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveModality('audio')}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border text-xs font-semibold transition-all ${
                  activeModality === 'audio'
                    ? 'border-indigo-500 bg-indigo-950/40 text-indigo-300 shadow-md shadow-indigo-500/10'
                    : 'border-slate-800 bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Mic className="h-5 w-5 mb-1 text-indigo-400" />
                <span>Audio Speech</span>
                <span className="text-[10px] text-slate-500 font-normal">WAV, MP3, M4A</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveModality('multimodal')}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border text-xs font-semibold transition-all ${
                  activeModality === 'multimodal'
                    ? 'border-emerald-500 bg-emerald-950/40 text-emerald-300 shadow-md shadow-emerald-500/10'
                    : 'border-slate-800 bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Layers className="h-5 w-5 mb-1 text-emerald-400" />
                <span>Multimodal Fusion</span>
                <span className="text-[10px] text-slate-500 font-normal">AV + Lip-Sync</span>
              </button>
            </div>
          </div>

          {/* Upload Drop Zone */}
          <div>
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block mb-2">
              2. Upload Media File or Drop Here
            </label>
            
            <div
              onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`relative border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all flex flex-col items-center justify-center min-h-[220px] ${
                isDragging
                  ? 'border-cyan-400 bg-cyan-950/30'
                  : 'border-slate-800 bg-slate-900/40 hover:border-slate-700 hover:bg-slate-900/70'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                accept={
                  activeModality === 'image'
                    ? 'image/jpeg,image/png,image/webp'
                    : activeModality === 'video'
                    ? 'video/mp4,video/quicktime,video/x-msvideo'
                    : activeModality === 'audio'
                    ? 'audio/wav,audio/mpeg,audio/mp4,audio/flac'
                    : 'image/*,video/*,audio/*'
                }
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileChange(e.target.files[0]);
                  }
                }}
              />

              <div className="h-14 w-14 rounded-2xl bg-slate-800/80 border border-slate-700 flex items-center justify-center text-cyan-400 mb-3 shadow-inner">
                <UploadCloud className="h-7 w-7" />
              </div>

              <h3 className="font-bold text-white text-sm">
                Drop your file here, or <span className="text-cyan-400 underline">browse device</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1 max-w-sm">
                Supported formats: {activeModality === 'image' ? 'JPG, PNG, WEBP (Up to 25MB)' : activeModality === 'video' ? 'MP4, MOV, AVI (Up to 100MB)' : activeModality === 'audio' ? 'WAV, MP3, M4A (Up to 50MB)' : 'Combined video and audio stream'}
              </p>

              <div className="mt-4 flex items-center space-x-3 text-[11px] text-slate-400">
                <span className="flex items-center space-x-1">
                  <CheckCircle className="h-3.5 w-3.5 text-emerald-400" />
                  <span>Encrypted Temporary Memory</span>
                </span>
                <span>•</span>
                <span className="flex items-center space-x-1">
                  <CheckCircle className="h-3.5 w-3.5 text-emerald-400" />
                  <span>EXIF & Hash Extracted</span>
                </span>
              </div>
            </div>
          </div>

          {/* Benchmark Preset Samples Selector */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Or Load A Curated Benchmark Sample
              </label>
              <span className="text-[11px] text-cyan-400">Standard Test Dataset</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {SAMPLE_BENCHMARKS.map((sample) => (
                <div
                  key={sample.id}
                  onClick={() => handleSelectBenchmark(sample)}
                  className={`p-3 rounded-xl border text-left cursor-pointer transition-all flex items-start space-x-3 ${
                    activeBenchmark?.id === sample.id
                      ? 'border-cyan-500 bg-cyan-950/40 ring-1 ring-cyan-500/50'
                      : 'border-slate-800 bg-slate-900/60 hover:bg-slate-800/80'
                  }`}
                >
                  <img
                    src={sample.thumbnailUrl}
                    alt={sample.title}
                    className="h-12 w-12 rounded-lg object-cover border border-slate-700 shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center space-x-1.5">
                      <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold border ${
                        sample.expectedClassification === 'FAKE'
                          ? 'bg-rose-950 text-rose-400 border-rose-800'
                          : sample.expectedClassification === 'SUSPICIOUS'
                          ? 'bg-amber-950 text-amber-400 border-amber-800'
                          : 'bg-emerald-950 text-emerald-400 border-emerald-800'
                      }`}>
                        {sample.expectedClassification}
                      </span>
                      <span className="text-[10px] text-slate-400 uppercase font-mono">{sample.mediaType}</span>
                    </div>
                    <p className="text-xs font-semibold text-slate-200 truncate mt-0.5">{sample.title}</p>
                    <p className="text-[10px] text-slate-400 truncate">{sample.category}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Right Col: Media Inspector Preview & Validation HUD */}
        <div className="lg:col-span-5 space-y-6">
          <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-5 space-y-5">
            
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="text-xs font-mono text-slate-400 uppercase font-semibold">
                Media Pre-Flight Verification
              </span>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                hasMedia ? 'bg-emerald-950 text-emerald-300 border-emerald-800' : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}>
                {hasMedia ? 'VALIDATED READY' : 'AWAITING FILE'}
              </span>
            </div>

            {/* Media Visual Preview Box */}
            <div className="rounded-xl overflow-hidden border border-slate-800 bg-slate-950 aspect-video relative flex items-center justify-center">
              {previewUrl ? (
                <>
                  {activeModality === 'video' ? (
                    <div className="relative w-full h-full flex items-center justify-center bg-slate-950">
                      <img
                        src={previewUrl}
                        alt="Video Preview"
                        className="w-full h-full object-cover opacity-80"
                      />
                      <div className="absolute inset-0 bg-slate-950/40 flex flex-col items-center justify-center">
                        <div className="h-12 w-12 rounded-full bg-cyan-500/80 text-slate-950 flex items-center justify-center shadow-lg">
                          <Play className="h-6 w-6 ml-0.5" />
                        </div>
                        <span className="text-[10px] font-mono text-cyan-300 mt-2 bg-slate-950/80 px-2 py-0.5 rounded">
                          Video Frame Track Loaded
                        </span>
                      </div>
                    </div>
                  ) : activeModality === 'audio' ? (
                    <div className="w-full h-full p-6 flex flex-col items-center justify-center space-y-3 bg-gradient-to-br from-indigo-950/40 to-slate-950">
                      <div className="h-14 w-14 rounded-full bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
                        <Mic className="h-7 w-7" />
                      </div>
                      <div className="text-center">
                        <p className="text-xs font-bold text-white">Audio Speech Track</p>
                        <p className="text-[10px] text-slate-400 font-mono">44.1 kHz / 16-bit PCM waveform</p>
                      </div>
                      {/* Audio wave bars animation */}
                      <div className="flex items-center space-x-1 h-6">
                        {[40, 70, 30, 90, 60, 80, 50, 95, 40, 75, 55, 30].map((h, i) => (
                          <div
                            key={i}
                            className="w-1 bg-indigo-400 rounded-full"
                            style={{ height: `${h}%` }}
                          />
                        ))}
                      </div>
                    </div>
                  ) : (
                    <img
                      src={previewUrl}
                      alt="Media Ingestion Preview"
                      className="w-full h-full object-cover"
                    />
                  )}
                </>
              ) : (
                <div className="text-center p-6 text-slate-500 space-y-2">
                  <ImageIcon className="h-10 w-10 mx-auto opacity-40" />
                  <p className="text-xs">No media loaded for inspection.</p>
                </div>
              )}
            </div>

            {/* File Metadata Details */}
            {hasMedia && (
              <div className="space-y-3 font-mono text-xs">
                <div className="bg-slate-950/80 rounded-xl p-3 border border-slate-800 space-y-2 text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Target File:</span>
                    <span className="font-semibold text-white truncate max-w-[180px]">
                      {activeBenchmark ? activeBenchmark.title : selectedFile?.name}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">File Size:</span>
                    <span>
                      {(((activeBenchmark?.fileSize || selectedFile?.size || 0) / 1024 / 1024)).toFixed(2)} MB
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Modality:</span>
                    <span className="text-cyan-400 uppercase font-bold">{activeModality}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">SHA-256 Hash:</span>
                    <span className="text-slate-400 truncate max-w-[170px]" title={fileHash || ''}>
                      {fileHash?.slice(0, 18)}...
                    </span>
                  </div>
                </div>

                {activeBenchmark && (
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-300">
                    <span className="text-slate-400 font-bold block mb-1">Benchmark Profile:</span>
                    <p className="text-slate-300">{activeBenchmark.description}</p>
                    <p className="text-cyan-400 mt-1">Expected: <strong>{activeBenchmark.expectedClassification}</strong> ({activeBenchmark.manipulationType})</p>
                  </div>
                )}
              </div>
            )}

            {/* Action Button */}
            <div>
              <button
                id="start-detection-btn"
                onClick={handleTriggerAnalysis}
                disabled={!hasMedia || isAnalyzing}
                className={`w-full py-3.5 px-4 rounded-xl font-bold text-sm flex items-center justify-center space-x-2 transition-all shadow-lg ${
                  hasMedia && !isAnalyzing
                    ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-cyan-500/25 cursor-pointer transform hover:-translate-y-0.5'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                }`}
              >
                {isAnalyzing ? (
                  <>
                    <RefreshCw className="h-4 w-4 animate-spin text-cyan-400" />
                    <span>Executing Multimodal Forensic AI...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4" />
                    <span>Start Forensic Deepfake Detection</span>
                  </>
                )}
              </button>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
};
