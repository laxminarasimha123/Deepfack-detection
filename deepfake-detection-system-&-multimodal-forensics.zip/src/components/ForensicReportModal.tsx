import React from 'react';
import { 
  X, 
  Download, 
  Printer, 
  FileJson, 
  ShieldCheck, 
  ShieldAlert, 
  AlertTriangle, 
  CheckCircle2, 
  Binary, 
  Calendar, 
  Cpu, 
  UserCheck, 
  Share2
} from 'lucide-react';
import { ForensicCase } from '../types';
import { exportForensicReportPDF, exportForensicReportJSON } from '../utils/pdfGenerator';

interface ForensicReportModalProps {
  caseData: ForensicCase;
  onClose: () => void;
  onVerifyCase?: (caseId: string) => void;
}

export const ForensicReportModal: React.FC<ForensicReportModalProps> = ({
  caseData,
  onClose,
  onVerifyCase,
}) => {
  const isFake = caseData.classification === 'FAKE';
  const isSuspicious = caseData.classification === 'SUSPICIOUS';
  const isReal = caseData.classification === 'REAL';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6">
      <div className="relative w-full max-w-4xl rounded-2xl border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Modal Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center space-x-3">
            <div className="h-8 w-8 rounded-lg bg-cyan-950 border border-cyan-500/40 flex items-center justify-center text-cyan-400 font-mono text-xs font-bold">
              DFS
            </div>
            <div>
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                Official Forensic Media Report
              </h2>
              <p className="text-[11px] font-mono text-cyan-400">
                CASE REF: {caseData.caseNumber}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => exportForensicReportJSON(caseData)}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg text-xs flex items-center space-x-1"
              title="Download JSON"
            >
              <FileJson className="h-4 w-4" />
            </button>
            <button
              onClick={() => window.print()}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg text-xs flex items-center space-x-1"
              title="Print Report"
            >
              <Printer className="h-4 w-4" />
            </button>
            <button
              onClick={() => exportForensicReportPDF(caseData)}
              className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold flex items-center space-x-1.5 shadow-md shadow-cyan-500/20"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Download PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors ml-2"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Report Content */}
        <div className="overflow-y-auto p-6 space-y-6 text-xs text-slate-300 font-sans print:p-0">
          
          {/* Section 1: Executive Classification Banner */}
          <div className={`rounded-xl border p-5 ${
            isFake
              ? 'border-rose-600/50 bg-rose-950/40 text-rose-200'
              : isSuspicious
              ? 'border-amber-600/50 bg-amber-950/40 text-amber-200'
              : 'border-emerald-600/50 bg-emerald-950/40 text-emerald-200'
          }`}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center space-x-3">
                <div className={`h-12 w-12 rounded-xl flex items-center justify-center border font-bold text-lg ${
                  isFake ? 'bg-rose-900 border-rose-500 text-rose-300' : isSuspicious ? 'bg-amber-900 border-amber-500 text-amber-300' : 'bg-emerald-900 border-emerald-500 text-emerald-300'
                }`}>
                  {isFake ? 'FAKE' : isSuspicious ? 'SUSP' : 'REAL'}
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider font-mono opacity-80">
                    Forensic AI Verdict
                  </div>
                  <div className="text-xl font-black tracking-tight text-white">
                    {caseData.classification} (Confidence: {caseData.confidenceScore.toFixed(1)}%)
                  </div>
                  <div className="text-xs font-semibold mt-0.5">
                    Calculated Risk: {caseData.riskScore.toFixed(1)}% — {caseData.riskLevel} SEVERITY
                  </div>
                </div>
              </div>

              <div className="font-mono text-right text-[11px] space-y-1">
                <div>Model: {caseData.modelName}</div>
                <div>Version: {caseData.modelVersion}</div>
                <div>Execution: {new Date(caseData.completedAt).toLocaleString()}</div>
              </div>
            </div>
          </div>

          {/* Section 2: File & Cryptographic Metadata */}
          <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4 space-y-3 font-mono">
            <h3 className="font-bold text-white text-xs uppercase tracking-wider border-b border-slate-800 pb-2">
              1. Digital Media & Chain-of-Custody Metadata
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-slate-400">
              <div>
                <span className="block text-slate-500 text-[10px]">File Name:</span>
                <span className="text-slate-200 font-semibold truncate block">{caseData.fileName}</span>
              </div>
              <div>
                <span className="block text-slate-500 text-[10px]">File Size / Format:</span>
                <span className="text-slate-200">{(caseData.fileSize / 1024 / 1024).toFixed(2)} MB ({caseData.metadata.fileType})</span>
              </div>
              <div>
                <span className="block text-slate-500 text-[10px]">Resolution / Duration:</span>
                <span className="text-slate-200">{caseData.metadata.dimensions || caseData.metadata.duration || 'N/A'}</span>
              </div>
              <div className="sm:col-span-2 md:col-span-3">
                <span className="block text-slate-500 text-[10px]">Cryptographic SHA-256 Digest:</span>
                <span className="text-cyan-400 text-[11px] select-all break-all">{caseData.metadata.sha256Hash}</span>
              </div>
            </div>
          </div>

          {/* Section 3: Modality Risk Score Breakdown */}
          <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4 space-y-3">
            <h3 className="font-bold text-white text-xs uppercase tracking-wider border-b border-slate-800 pb-2">
              2. Multimodal Anomaly Scores
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 font-mono block">Facial Consistency</span>
                <span className="text-lg font-bold font-mono text-white mt-1 block">{caseData.faceAnalysisScore}%</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 font-mono block">Artifact ELA</span>
                <span className="text-lg font-bold font-mono text-white mt-1 block">{caseData.artifactAnalysisScore}%</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 font-mono block">Metadata Provenance</span>
                <span className="text-lg font-bold font-mono text-white mt-1 block">{caseData.metadataAnalysisScore}%</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 font-mono block">Temporal / Spectral</span>
                <span className="text-lg font-bold font-mono text-white mt-1 block">
                  {caseData.temporalAnalysisScore || caseData.spectralAnalysisScore || 92}%
                </span>
              </div>
            </div>
          </div>

          {/* Section 4: Foreground vs Background Forensic Assessment */}
          {(caseData.subjectAuthenticity || caseData.backgroundAuthenticity) && (
            <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4 space-y-3">
              <h3 className="font-bold text-white text-xs uppercase tracking-wider border-b border-slate-800 pb-2 flex justify-between items-center">
                <span>3. Foreground & Background Separation Analysis</span>
                {caseData.manipulationType && (
                  <span className="text-[10px] text-purple-400 font-mono">{caseData.manipulationType}</span>
                )}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
                  <span className="font-bold text-cyan-300 block">Subject / Foreground:</span>
                  <p className="text-slate-300 leading-relaxed">{caseData.subjectAuthenticity}</p>
                </div>
                <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
                  <span className="font-bold text-purple-300 block">Background Environment:</span>
                  <p className="text-slate-300 leading-relaxed">{caseData.backgroundAuthenticity}</p>
                </div>
              </div>
            </div>
          )}

          {/* Section 4: Strict Forensic Rubric & Indicators */}
          {((caseData.aiGenerationIndicators && caseData.aiGenerationIndicators.length > 0) ||
            (caseData.faceManipulationIndicators && caseData.faceManipulationIndicators.length > 0) ||
            (caseData.compositeIndicators && caseData.compositeIndicators.length > 0) ||
            (caseData.limitations && caseData.limitations.length > 0)) && (
            <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4 space-y-3">
              <h3 className="font-bold text-white text-xs uppercase tracking-wider border-b border-slate-800 pb-2 flex justify-between items-center">
                <span>3. Strict Forensic Rubric & Categorical Indicators</span>
                <span className="text-[10px] text-cyan-400 font-normal">Standard 10-Point Analysis</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
                {caseData.aiGenerationIndicators && caseData.aiGenerationIndicators.length > 0 && (
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="font-bold text-rose-300 block mb-1">AI-Generation Indicators:</span>
                    <ul className="list-disc pl-4 space-y-0.5 text-slate-300">
                      {caseData.aiGenerationIndicators.map((ind, i) => (
                        <li key={i}>{ind}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {caseData.faceManipulationIndicators && caseData.faceManipulationIndicators.length > 0 && (
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="font-bold text-amber-300 block mb-1">Face-Swap / Manipulation:</span>
                    <ul className="list-disc pl-4 space-y-0.5 text-slate-300">
                      {caseData.faceManipulationIndicators.map((ind, i) => (
                        <li key={i}>{ind}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {caseData.compositeIndicators && caseData.compositeIndicators.length > 0 && (
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="font-bold text-indigo-300 block mb-1">Composite Inconsistencies:</span>
                    <ul className="list-disc pl-4 space-y-0.5 text-slate-300">
                      {caseData.compositeIndicators.map((ind, i) => (
                        <li key={i}>{ind}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {caseData.limitations && caseData.limitations.length > 0 && (
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="font-bold text-slate-400 block mb-1">Forensic Limitations:</span>
                    <ul className="list-disc pl-4 space-y-0.5 text-slate-400">
                      {caseData.limitations.map((ind, i) => (
                        <li key={i}>{ind}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Section 5: Forensic Evidence & Findings */}
          <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4 space-y-3">
            <h3 className="font-bold text-white text-xs uppercase tracking-wider border-b border-slate-800 pb-2">
              4. Forensic Evidence Logs & Detected Anomalies
            </h3>
            <div className="space-y-2.5">
              {(caseData.forensicEvidence || []).map((ev) => (
                <div key={ev.id} className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
                  <div className="flex justify-between items-center font-mono">
                    <span className="font-bold text-white">{ev.title}</span>
                    <span className="text-[10px] text-rose-400 uppercase font-bold">
                      [{ev.severity}] Severity • Score: {ev.score}/100
                    </span>
                  </div>
                  <p className="text-slate-300 leading-relaxed text-[11px]">{ev.description}</p>
                  {ev.technicalDetails && (
                    <div className="text-[10px] font-mono text-cyan-400 bg-slate-950 p-1 rounded">
                      {ev.technicalDetails}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Section 5: Conclusion & Chain of Custody Sign-off */}
          <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4 space-y-3">
            <h3 className="font-bold text-white text-xs uppercase tracking-wider border-b border-slate-800 pb-2">
              4. Forensic Examiner Evaluation & Sign-off
            </h3>
            <p className="text-slate-300 leading-relaxed text-[11px]">
              {caseData.conclusion}
            </p>

            <div className="mt-4 pt-3 border-t border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-mono block">Examiner in Charge:</span>
                <span className="text-xs font-bold text-white">{caseData.userName} (Digital Forensics Unit)</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-mono block">Digital Signature:</span>
                <span className="text-[11px] font-mono text-cyan-400 font-bold">
                  SIG-DF-{caseData.caseNumber}-AUTH-OK
                </span>
              </div>
            </div>
          </div>

          {/* Section 6: Legal & Forensic Disclaimer */}
          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-[10px] text-slate-500 italic leading-relaxed">
            {caseData.disclaimer}
          </div>

        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-3 border-t border-slate-800 bg-slate-950">
          <span className="text-[11px] font-mono text-slate-500">
            System UID: DFS-2026-X88 • Timestamp: {new Date().toUTCString()}
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 transition-colors"
          >
            Close Report
          </button>
        </div>

      </div>
    </div>
  );
};
