import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  Download, 
  Trash2, 
  Eye, 
  FileText, 
  FileSpreadsheet, 
  ArrowUpDown, 
  RefreshCw,
  Plus
} from 'lucide-react';
import { ForensicCase, MediaType, RiskLevel } from '../types';
import { exportCasesCSV, exportForensicReportPDF } from '../utils/pdfGenerator';

interface DetectionHistoryTableProps {
  cases: ForensicCase[];
  onSelectCase: (c: ForensicCase) => void;
  onDeleteCase: (id: string) => void;
  onUploadNew: () => void;
}

export const DetectionHistoryTable: React.FC<DetectionHistoryTableProps> = ({
  cases,
  onSelectCase,
  onDeleteCase,
  onUploadNew,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [mediaFilter, setMediaFilter] = useState<string>('all');
  const [classificationFilter, setClassificationFilter] = useState<string>('all');
  const [riskFilter, setRiskFilter] = useState<string>('all');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest' | 'highest_risk'>('newest');

  // Filter & Search logic
  const filteredCases = cases.filter((c) => {
    const matchesSearch =
      searchTerm.trim() === '' ||
      c.fileName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.caseNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.conclusion.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesMedia = mediaFilter === 'all' || c.mediaType === mediaFilter;
    const matchesClass = classificationFilter === 'all' || c.classification === classificationFilter;
    const matchesRisk = riskFilter === 'all' || c.riskLevel === riskFilter;

    return matchesSearch && matchesMedia && matchesClass && matchesRisk;
  });

  // Sort logic
  const sortedCases = [...filteredCases].sort((a, b) => {
    if (sortOrder === 'newest') {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
    if (sortOrder === 'oldest') {
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    }
    if (sortOrder === 'highest_risk') {
      return b.riskScore - a.riskScore;
    }
    return 0;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
            Detection Case Registry
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Search, filter, inspect, and export all digital media forensic investigations.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => exportCasesCSV(sortedCases)}
            className="inline-flex items-center space-x-1.5 px-3.5 py-2 rounded-xl border border-slate-800 bg-slate-900 text-xs font-semibold text-slate-300 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <FileSpreadsheet className="h-4 w-4 text-emerald-400" />
            <span>Export CSV ({sortedCases.length})</span>
          </button>

          <button
            onClick={onUploadNew}
            className="inline-flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-xs font-bold text-slate-950 shadow-md shadow-cyan-500/20 transition-all"
          >
            <Plus className="h-4 w-4" />
            <span>New Ingestion</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Toolbar */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4 space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          
          {/* Search Box */}
          <div className="lg:col-span-2 relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
            <input
              type="text"
              placeholder="Search case ID, file name, keywords..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Media Type Filter */}
          <div>
            <select
              value={mediaFilter}
              onChange={(e) => setMediaFilter(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value="all">All Modalities</option>
              <option value="image">Images Only</option>
              <option value="video">Videos Only</option>
              <option value="audio">Audio Only</option>
              <option value="multimodal">Multimodal</option>
            </select>
          </div>

          {/* Classification Filter */}
          <div>
            <select
              value={classificationFilter}
              onChange={(e) => setClassificationFilter(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value="all">All Verdicts</option>
              <option value="REAL">REAL Only</option>
              <option value="FAKE">FAKE (Deepfakes)</option>
              <option value="SUSPICIOUS">SUSPICIOUS</option>
              <option value="INCONCLUSIVE">INCONCLUSIVE</option>
            </select>
          </div>

          {/* Sort Order */}
          <div>
            <select
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value as any)}
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
            >
              <option value="newest">Sort: Newest First</option>
              <option value="oldest">Sort: Oldest First</option>
              <option value="highest_risk">Sort: Highest Risk</option>
            </select>
          </div>

        </div>
      </div>

      {/* Cases Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 text-slate-400 font-mono border-b border-slate-800 uppercase tracking-wider">
              <tr>
                <th className="px-6 py-3.5">Case ID</th>
                <th className="px-6 py-3.5">File Name</th>
                <th className="px-6 py-3.5">Modality</th>
                <th className="px-6 py-3.5">Classification</th>
                <th className="px-6 py-3.5">Confidence</th>
                <th className="px-6 py-3.5">Risk Score</th>
                <th className="px-6 py-3.5">Timestamp</th>
                <th className="px-6 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {sortedCases.length > 0 ? (
                sortedCases.map((c) => {
                  let badgeClass = 'bg-rose-950 text-rose-400 border-rose-800';
                  if (c.classification === 'REAL') badgeClass = 'bg-emerald-950 text-emerald-400 border-emerald-800';
                  if (c.classification === 'SUSPICIOUS') badgeClass = 'bg-amber-950 text-amber-400 border-amber-800';
                  if (c.classification === 'INCONCLUSIVE') badgeClass = 'bg-slate-800 text-slate-300 border-slate-700';

                  return (
                    <tr 
                      key={c.id}
                      className="hover:bg-slate-800/40 transition-colors cursor-pointer group"
                      onClick={() => onSelectCase(c)}
                    >
                      <td className="px-6 py-4 font-mono font-bold text-cyan-400">
                        {c.caseNumber}
                      </td>
                      <td className="px-6 py-4">
                        <div className="font-semibold text-slate-200 truncate max-w-[220px]">
                          {c.fileName}
                        </div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          {(c.fileSize / 1024 / 1024).toFixed(2)} MB
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="inline-block px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-slate-800 text-slate-300 border border-slate-700">
                          {c.mediaType}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold border ${badgeClass}`}>
                          {c.classification}
                        </span>
                      </td>
                      <td className="px-6 py-4 font-mono text-slate-300 font-medium">
                        {c.confidenceScore.toFixed(1)}%
                      </td>
                      <td className="px-6 py-4">
                        <span className={`text-xs font-semibold ${
                          c.riskLevel === 'CRITICAL' || c.riskLevel === 'HIGH'
                            ? 'text-rose-400'
                            : c.riskLevel === 'MEDIUM'
                            ? 'text-amber-400'
                            : 'text-emerald-400'
                        }`}>
                          {c.riskScore.toFixed(0)}% ({c.riskLevel})
                        </span>
                      </td>
                      <td className="px-6 py-4 text-slate-400 text-[11px]">
                        {new Date(c.createdAt).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end space-x-1.5">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectCase(c);
                            }}
                            className="p-1.5 text-slate-300 hover:text-cyan-300 hover:bg-slate-800 rounded-lg transition-colors"
                            title="Inspect Findings"
                          >
                            <Eye className="h-4 w-4" />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              exportForensicReportPDF(c);
                            }}
                            className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                            title="Download PDF"
                          >
                            <FileText className="h-4 w-4" />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              if (confirm(`Are you sure you want to delete case ${c.caseNumber}?`)) {
                                onDeleteCase(c.id);
                              }
                            }}
                            className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors"
                            title="Delete Case"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={8} className="px-6 py-12 text-center text-slate-500">
                    <p className="text-sm">No forensic cases match your search or filter parameters.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
