import React, { useEffect, useState } from 'react';
import { 
  ShieldCheck, 
  Cpu, 
  ScanFace, 
  Activity, 
  Layers, 
  CheckCircle2, 
  Search, 
  Binary,
  Radio
} from 'lucide-react';
import { MediaType } from '../types';

interface InteractiveScannerProps {
  mediaType: MediaType;
  fileName: string;
  isBackendReady?: boolean;
  onComplete: () => void;
}

export const InteractiveScanner: React.FC<InteractiveScannerProps> = ({
  mediaType,
  fileName,
  isBackendReady = true,
  onComplete,
}) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [progress, setProgress] = useState(10);

  const steps = [
    { title: 'Media Ingestion & Cryptographic Checksum', desc: 'Validating SHA-256 hash, container integrity, and EXIF/C2PA metadata.' },
    { title: 'Facial ROI & Landmark Biometrics', desc: 'Detecting 68 facial landmarks, corneal specular reflection vectors, and iris geometry.' },
    { title: 'Frequency Domain & Compression ELA', desc: 'Scanning Fourier transform residuals, DCT quantization tables, and GAN deconvolution grid artifacts.' },
    { title: mediaType === 'audio' || mediaType === 'multimodal' ? 'Spectrogram Voiceprint & Vocoder Analysis' : 'Inter-Frame Optical Flow & Blinking Dynamics', desc: mediaType === 'audio' || mediaType === 'multimodal' ? 'Measuring 16kHz-22kHz Nyquist cutoff, robotic pitch stability, and formant phase.' : 'Tracking temporal velocity jitter and spontaneous eyelid closure frequencies.' },
    { title: 'Multimodal Evidence Fusion & Risk Scoring', desc: 'Synthesizing weighted confidence vectors across vision, spectral, and temporal classifiers.' },
  ];

  useEffect(() => {
    let completedTriggered = false;

    const timer = setInterval(() => {
      setProgress((prev) => {
        // If not ready and reached 92%, pause and wait for backend
        if (prev >= 92 && !isBackendReady) {
          setCurrentStep(4);
          return 92;
        }

        if (prev >= 100) {
          clearInterval(timer);
          if (!completedTriggered) {
            completedTriggered = true;
            setTimeout(() => {
              onComplete();
            }, 300);
          }
          return 100;
        }

        const stepJump = !isBackendReady && prev > 70 ? 2 : 5;
        const next = Math.min(prev + stepJump, 100);
        const stepIdx = Math.min(Math.floor((next / 100) * steps.length), steps.length - 1);
        setCurrentStep(stepIdx);
        return next;
      });
    }, 100);

    return () => clearInterval(timer);
  }, [onComplete, isBackendReady, steps.length]);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-4">
      <div className="max-w-xl w-full rounded-2xl border border-cyan-500/40 bg-slate-900/90 p-6 sm:p-8 shadow-2xl relative overflow-hidden space-y-6">
        
        {/* Ambient Grid */}
        <div className="forensic-grid absolute inset-0 opacity-15 pointer-events-none" />

        {/* Scan Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 relative z-10">
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 rounded-xl bg-cyan-950 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
              <Cpu className="h-5 w-5 animate-pulse" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Forensic Detection Pipeline Running</h3>
              <p className="text-xs text-slate-400 font-mono truncate max-w-[280px]">Target: {fileName}</p>
            </div>
          </div>
          <span className="text-xs font-mono font-bold text-cyan-400 bg-cyan-950/80 px-2.5 py-1 rounded-full border border-cyan-800">
            {progress}%
          </span>
        </div>

        {/* Main Progress Bar */}
        <div className="space-y-2 relative z-10">
          <div className="flex justify-between text-xs font-mono text-slate-400">
            <span>Pipeline Execution</span>
            <span>{Math.round(progress)}% Completed</span>
          </div>
          <div className="h-2.5 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-500 rounded-full transition-all duration-150"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Active Steps List */}
        <div className="space-y-3 relative z-10">
          {steps.map((step, idx) => {
            const isFinished = idx < currentStep;
            const isCurrent = idx === currentStep;

            return (
              <div
                key={idx}
                className={`p-3 rounded-xl border transition-all flex items-start space-x-3 ${
                  isCurrent
                    ? 'border-cyan-500/80 bg-cyan-950/40 shadow-sm'
                    : isFinished
                    ? 'border-slate-800/80 bg-slate-950/60 opacity-80'
                    : 'border-slate-900 bg-slate-950/30 opacity-40'
                }`}
              >
                <div className="mt-0.5">
                  {isFinished ? (
                    <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  ) : isCurrent ? (
                    <Radio className="h-4 w-4 text-cyan-400 animate-spin" />
                  ) : (
                    <div className="h-4 w-4 rounded-full border border-slate-700" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h4 className={`text-xs font-bold ${isCurrent ? 'text-cyan-300' : 'text-slate-200'}`}>
                      {step.title}
                    </h4>
                    {isCurrent && (
                      <span className="text-[10px] font-mono text-cyan-400 animate-pulse uppercase">
                        ANALYZING...
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">{step.desc}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Telemetry Footer */}
        <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800/80 flex items-center justify-between text-[10px] font-mono text-slate-400 relative z-10">
          <span className="flex items-center space-x-1.5">
            <Binary className="h-3 w-3 text-cyan-400" />
            <span>ResNet-FF++ • SpectralGuard • SyncNet</span>
          </span>
          <span className="text-cyan-400">Zero-Retention Mode</span>
        </div>

      </div>
    </div>
  );
};
