import React from 'react';
import { 
  ShieldCheck, 
  Cpu, 
  ScanFace, 
  Film, 
  Mic, 
  FileCheck2, 
  ArrowRight, 
  Lock, 
  Binary, 
  Activity, 
  CheckCircle2, 
  Zap, 
  Sparkles,
  Layers,
  FileSpreadsheet
} from 'lucide-react';
import { SAMPLE_BENCHMARKS } from '../data/sampleMedia';
import { BenchmarkSample } from '../types';

interface LandingHeroProps {
  onStartDetection: () => void;
  onSelectBenchmark: (sample: BenchmarkSample) => void;
}

export const LandingHero: React.FC<LandingHeroProps> = ({
  onStartDetection,
  onSelectBenchmark,
}) => {
  return (
    <div className="relative overflow-hidden pt-6 pb-16">
      {/* Background Decorative Glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-cyan-500/10 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute top-1/3 right-10 w-[400px] h-[300px] bg-blue-600/10 rounded-full blur-3xl pointer-events-none -z-10" />

      {/* Hero Section */}
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-4xl mx-auto space-y-6">
          
          {/* Badge */}
          <div className="inline-flex items-center space-x-2 rounded-full border border-cyan-500/30 bg-cyan-950/40 px-3.5 py-1 text-xs font-medium text-cyan-300 backdrop-blur-sm shadow-sm">
            <Sparkles className="h-3.5 w-3.5 text-cyan-400" />
            <span>Next-Generation Multimodal AI Forensic Platform</span>
          </div>

          {/* Heading */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight">
            Detect AI Deepfakes With{' '}
            <span className="bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500 bg-clip-text text-transparent">
              Forensic Precision
            </span>
          </h1>

          {/* Description */}
          <p className="text-base sm:text-lg text-slate-300 max-w-3xl mx-auto leading-relaxed">
            An intelligent forensic platform capable of analyzing digital media and identifying synthetic or manipulated content across <strong className="text-white">Images</strong>, <strong className="text-white">Videos</strong>, <strong className="text-white">Audio Speech</strong>, and <strong className="text-white">Multimodal Streams</strong> using explainable AI evidence fusion.
          </p>

          {/* Main CTAs */}
          <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
            <button
              id="hero-cta-analyze"
              onClick={onStartDetection}
              className="inline-flex items-center space-x-2 rounded-xl bg-cyan-500 px-6 py-3.5 text-sm font-bold text-slate-950 shadow-lg shadow-cyan-500/25 hover:bg-cyan-400 hover:shadow-cyan-500/40 transition-all transform hover:-translate-y-0.5 active:translate-y-0"
            >
              <span>Analyze Your Media</span>
              <ArrowRight className="h-4 w-4" />
            </button>

            <button
              id="hero-cta-samples"
              onClick={() => onSelectBenchmark(SAMPLE_BENCHMARKS[0])}
              className="inline-flex items-center space-x-2 rounded-xl border border-slate-700 bg-slate-900/90 px-6 py-3.5 text-sm font-semibold text-slate-200 hover:bg-slate-800 hover:text-white transition-colors"
            >
              <Layers className="h-4 w-4 text-cyan-400" />
              <span>Try Benchmark Deepfake</span>
            </button>
          </div>

          {/* Security & Verification trust badges */}
          <div className="flex flex-wrap justify-center items-center gap-6 pt-6 text-xs text-slate-400">
            <div className="flex items-center space-x-1.5">
              <Lock className="h-3.5 w-3.5 text-cyan-400" />
              <span>Zero-Retention Temporary Storage</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <Binary className="h-3.5 w-3.5 text-cyan-400" />
              <span>SHA-256 Chain of Custody</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
              <span>Certified Forensic PDF Reports</span>
            </div>
          </div>

        </div>

        {/* Interactive Forensic Showcase Card */}
        <div className="mt-14 rounded-2xl border border-slate-800 bg-slate-900/60 p-6 backdrop-blur-xl shadow-2xl relative overflow-hidden">
          <div className="forensic-grid absolute inset-0 opacity-20 pointer-events-none" />
          
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Visual Inspection Panel */}
            <div className="lg:col-span-6 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center space-x-2">
                  <div className="h-2.5 w-2.5 rounded-full bg-rose-500 animate-pulse" />
                  <span className="text-xs font-mono text-slate-300 font-semibold uppercase tracking-wider">
                    Live Multimodal Forensic Pipeline
                  </span>
                </div>
                <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/40">
                  CASE: DF-2026-X01
                </span>
              </div>

              {/* Mock Scan Box with Overlay */}
              <div className="relative rounded-xl overflow-hidden border border-slate-700/80 bg-slate-950 aspect-video group">
                <img
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80"
                  alt="Forensic Scanning Target"
                  className="w-full h-full object-cover opacity-80 filter brightness-90 contrast-110"
                />
                
                {/* Scanline Animation */}
                <div className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_15px_#22d3ee] animate-scanline pointer-events-none" />

                {/* Facial Bounding Box & Landmark Overlay */}
                <div className="absolute top-[20%] left-[32%] w-[38%] h-[58%] border-2 border-dashed border-rose-500 rounded-lg bg-rose-500/10 pointer-events-none">
                  <div className="absolute -top-3 left-2 bg-rose-950 text-rose-300 text-[10px] font-mono px-1.5 py-0.5 rounded border border-rose-600">
                    FACIAL ROI: ANOMALY 96.2%
                  </div>
                  {/* Iris Specular Points */}
                  <div className="absolute top-[35%] left-[28%] h-2 w-2 rounded-full bg-cyan-400 ring-2 ring-cyan-300 shadow-[0_0_8px_#22d3ee]" />
                  <div className="absolute top-[35%] right-[28%] h-2 w-2 rounded-full bg-rose-500 ring-2 ring-rose-300 shadow-[0_0_8px_#f43f5e]" />
                  <div className="absolute bottom-2 inset-x-2 text-[9px] font-mono bg-slate-950/80 text-rose-300 px-1 py-0.5 rounded text-center">
                    Iris Light Ray Vector Mismatch (38.4°)
                  </div>
                </div>

                {/* Technical Overlay HUD */}
                <div className="absolute bottom-2 left-2 right-2 flex justify-between items-center text-[10px] font-mono bg-slate-950/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-800 text-slate-300">
                  <span>RES: 2048x1365 | DCT-ELA: +24.8dB</span>
                  <span className="text-rose-400 font-bold">STATUS: DEEPFAKE DETECTED</span>
                </div>
              </div>
            </div>

            {/* Forensic Scores & Evidence Matrix */}
            <div className="lg:col-span-6 space-y-4">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">Classification Assessment</span>
                  <span className="text-xs font-mono font-bold text-rose-400">94.6% Confidence</span>
                </div>
                <div className="flex items-center space-x-3 bg-rose-950/40 border border-rose-500/40 rounded-xl p-3">
                  <div className="h-10 w-10 rounded-lg bg-rose-500/20 border border-rose-500/60 flex items-center justify-center text-rose-400 font-black text-sm">
                    FAKE
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">DEEPFAKE / SYNTHETIC MEDIA</h4>
                    <p className="text-xs text-rose-200/80">Multiple synthetic facial generative artifacts and compression mismatches identified.</p>
                  </div>
                </div>
              </div>

              {/* Progress Bars for Modalities */}
              <div className="space-y-2.5 pt-1">
                <div>
                  <div className="flex justify-between text-xs mb-1 font-medium">
                    <span className="text-slate-300">Facial Consistency Analysis</span>
                    <span className="font-mono text-rose-400 font-bold">96% Risk</span>
                  </div>
                  <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-orange-500 to-rose-500 w-[96%] rounded-full" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1 font-medium">
                    <span className="text-slate-300">Artifact & Fourier Frequency Residuals</span>
                    <span className="font-mono text-rose-400 font-bold">91% Risk</span>
                  </div>
                  <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-amber-500 to-rose-500 w-[91%] rounded-full" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1 font-medium">
                    <span className="text-slate-300">Metadata Integrity & EXIF Provenance</span>
                    <span className="font-mono text-amber-400 font-bold">78% Anomaly</span>
                  </div>
                  <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-blue-500 to-amber-500 w-[78%] rounded-full" />
                  </div>
                </div>
              </div>

              {/* Quick Try Benchmarks */}
              <div className="pt-2">
                <span className="text-xs font-semibold text-slate-400 block mb-2">Test Curated Benchmark Samples:</span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {SAMPLE_BENCHMARKS.slice(0, 4).map((sample) => (
                    <button
                      key={sample.id}
                      onClick={() => onSelectBenchmark(sample)}
                      className="p-2 rounded-lg border border-slate-800 bg-slate-950/80 hover:border-cyan-500/50 hover:bg-slate-900 transition-all text-left text-xs group"
                    >
                      <span className={`inline-block px-1.5 py-0.5 rounded text-[9px] font-bold mb-1 ${
                        sample.expectedClassification === 'FAKE'
                          ? 'bg-rose-950 text-rose-400 border border-rose-800'
                          : sample.expectedClassification === 'SUSPICIOUS'
                          ? 'bg-amber-950 text-amber-400 border border-amber-800'
                          : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      }`}>
                        {sample.expectedClassification}
                      </span>
                      <p className="font-medium text-slate-200 line-clamp-1 group-hover:text-cyan-300 transition-colors">
                        {sample.title}
                      </p>
                      <span className="text-[10px] text-slate-400 uppercase">{sample.mediaType}</span>
                    </button>
                  ))}
                </div>
              </div>

            </div>

          </div>
        </div>

        {/* Modality Capabilities Grid */}
        <div className="mt-20">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-white">
              Comprehensive Multimodal Detection Engines
            </h2>
            <p className="text-slate-400 text-sm mt-2">
              Cross-modality evidence fusion examining micro-features across visual, temporal, audio, and metadata domains.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            
            {/* Image Forensics */}
            <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-5 hover:border-cyan-500/40 transition-colors space-y-3">
              <div className="h-10 w-10 rounded-lg bg-cyan-950/80 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <ScanFace className="h-5 w-5" />
              </div>
              <h3 className="font-bold text-white text-base">Image Deepfake Analysis</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Detects latent diffusion artifacts, GAN generator deconvolution fingerprints, facial landmark warping, and corneal reflection ray-mismatches.
              </p>
              <div className="text-[11px] font-mono text-cyan-300 bg-cyan-950/40 px-2 py-1 rounded border border-cyan-800/30">
                JPG, PNG, WEBP • ELA & PRNU
              </div>
            </div>

            {/* Video Forensics */}
            <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-5 hover:border-blue-500/40 transition-colors space-y-3">
              <div className="h-10 w-10 rounded-lg bg-blue-950/80 border border-blue-500/30 flex items-center justify-center text-blue-400">
                <Film className="h-5 w-5" />
              </div>
              <h3 className="font-bold text-white text-base">Video & Temporal Analysis</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Evaluates inter-frame optical flow consistency, face-tracking stability, spontaneous eyelid blink dynamics, and Wav2Lip boundary warping.
              </p>
              <div className="text-[11px] font-mono text-blue-300 bg-blue-950/40 px-2 py-1 rounded border border-blue-800/30">
                MP4, MOV, AVI • Frame Extraction
              </div>
            </div>

            {/* Audio Forensics */}
            <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-5 hover:border-indigo-500/40 transition-colors space-y-3">
              <div className="h-10 w-10 rounded-lg bg-indigo-950/80 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                <Mic className="h-5 w-5" />
              </div>
              <h3 className="font-bold text-white text-base">Audio & Voice Synthesis</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Inspects high-frequency Mel-spectrogram cutoffs (16kHz-22kHz), synthetic vocoder phase anomalies, robotic pitch constancy, and breath intake omission.
              </p>
              <div className="text-[11px] font-mono text-indigo-300 bg-indigo-950/40 px-2 py-1 rounded border border-indigo-800/30">
                WAV, MP3, M4A • Spectrogram AI
              </div>
            </div>

            {/* Multimodal Fusion */}
            <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-5 hover:border-emerald-500/40 transition-colors space-y-3">
              <div className="h-10 w-10 rounded-lg bg-emerald-950/80 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <Activity className="h-5 w-5" />
              </div>
              <h3 className="font-bold text-white text-base">Multimodal Fusion</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Calculates cross-modal Audio-Visual synchronization offsets (SyncNet), temporal viseme-phoneme delays, and fused risk probability vectors.
              </p>
              <div className="text-[11px] font-mono text-emerald-300 bg-emerald-950/40 px-2 py-1 rounded border border-emerald-800/30">
                Cross-Modal Sync • Decision Fusion
              </div>
            </div>

          </div>
        </div>

        {/* How System Works Pipeline */}
        <div className="mt-20 rounded-2xl border border-slate-800 bg-slate-900/40 p-8">
          <div className="text-center max-w-xl mx-auto mb-10">
            <h2 className="text-xl sm:text-2xl font-bold text-white">How The Detection Pipeline Works</h2>
            <p className="text-slate-400 text-xs mt-1">End-to-end media preprocessing to certified forensic report delivery</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 relative">
            <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 text-center space-y-2">
              <div className="text-xs font-mono text-cyan-400 font-bold">STEP 1</div>
              <div className="font-semibold text-sm text-white">Media Ingestion</div>
              <p className="text-[11px] text-slate-400">Secure upload, SHA-256 hashing, metadata & EXIF extraction.</p>
            </div>

            <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 text-center space-y-2">
              <div className="text-xs font-mono text-cyan-400 font-bold">STEP 2</div>
              <div className="font-semibold text-sm text-white">Preprocessing</div>
              <p className="text-[11px] text-slate-400">Face ROI detection, frame sampling, audio spectral FFT.</p>
            </div>

            <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 text-center space-y-2">
              <div className="text-xs font-mono text-cyan-400 font-bold">STEP 3</div>
              <div className="font-semibold text-sm text-white">AI Detection Models</div>
              <p className="text-[11px] text-slate-400">Ensemble inference across vision, temporal & speech networks.</p>
            </div>

            <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 text-center space-y-2">
              <div className="text-xs font-mono text-cyan-400 font-bold">STEP 4</div>
              <div className="font-semibold text-sm text-white">Evidence Fusion</div>
              <p className="text-[11px] text-slate-400">Multimodal risk scoring & anomaly severity weighting.</p>
            </div>

            <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 text-center space-y-2">
              <div className="text-xs font-mono text-cyan-400 font-bold">STEP 5</div>
              <div className="font-semibold text-sm text-white">Forensic Report</div>
              <p className="text-[11px] text-slate-400">Explainable findings, frame data, and downloadable PDF.</p>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
