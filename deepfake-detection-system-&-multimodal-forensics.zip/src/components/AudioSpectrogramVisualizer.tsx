import React from 'react';
import { Mic, Activity, AlertTriangle, CheckCircle, Info } from 'lucide-react';
import { AudioForensicProfile } from '../types';

interface AudioSpectrogramVisualizerProps {
  audioProfile: AudioForensicProfile;
  isFake: boolean;
}

export const AudioSpectrogramVisualizer: React.FC<AudioSpectrogramVisualizerProps> = ({
  audioProfile,
  isFake,
}) => {
  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 space-y-5">
      
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div className="flex items-center space-x-2">
          <div className="h-8 w-8 rounded-lg bg-indigo-950 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
            <Activity className="h-4 w-4" />
          </div>
          <div>
            <h3 className="font-bold text-white text-sm">Audio Spectral & Voiceprint Forensics</h3>
            <p className="text-[11px] text-slate-400 font-mono">Mel-Scale Frequency Spectrogram & Vocoder Anomaly Analysis</p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <span className={`px-2.5 py-0.5 rounded-full text-xs font-mono font-bold border ${
            isFake ? 'bg-rose-950 text-rose-400 border-rose-800' : 'bg-emerald-950 text-emerald-400 border-emerald-800'
          }`}>
            Synthetic Probability: {audioProfile.syntheticProbability.toFixed(1)}%
          </span>
        </div>
      </div>

      {/* Simulated Spectrogram Heatmap */}
      <div className="space-y-2">
        <div className="flex justify-between text-xs font-mono text-slate-400">
          <span>Frequency Spectrum (0 Hz — 22.05 kHz)</span>
          <span className="text-cyan-400">FFT Window: 2048 pts / Hanning</span>
        </div>

        <div className="h-44 w-full bg-slate-950 rounded-xl border border-slate-800 p-3 relative overflow-hidden flex flex-col justify-between">
          
          {/* Spectrogram color bands */}
          <div className="grid grid-cols-12 gap-1 h-full items-end">
            {audioProfile.spectralPoints.map((pt, idx) => {
              const isCutoffPoint = isFake && pt.freq >= 16000 && pt.sampleMagnitude < 5;

              return (
                <div key={idx} className="flex flex-col items-center h-full justify-end group relative">
                  
                  {/* Real magnitude reference bar */}
                  <div
                    className="w-full bg-slate-800/60 rounded-t opacity-40 absolute bottom-0 inset-x-0"
                    style={{ height: `${pt.realMagnitude}%` }}
                  />

                  {/* Sample measured magnitude */}
                  <div
                    className={`w-full rounded-t transition-all relative z-10 ${
                      isCutoffPoint
                        ? 'bg-rose-500 animate-pulse'
                        : isFake
                        ? 'bg-gradient-to-t from-indigo-600 via-amber-500 to-rose-500'
                        : 'bg-gradient-to-t from-blue-600 via-cyan-500 to-emerald-400'
                    }`}
                    style={{ height: `${Math.max(pt.sampleMagnitude, 4)}%` }}
                  />

                  {/* Frequency Label */}
                  <span className="text-[9px] font-mono text-slate-500 mt-1 whitespace-nowrap">
                    {pt.freq >= 1000 ? `${pt.freq / 1000}k` : `${pt.freq}`}
                  </span>

                  {/* Tooltip */}
                  <div className="absolute -top-10 bg-slate-900 border border-slate-700 text-[10px] font-mono p-1 rounded hidden group-hover:block z-30 whitespace-nowrap shadow-xl">
                    {pt.freq} Hz: {pt.sampleMagnitude} dB {isCutoffPoint && '(Brickwall Cutoff!)'}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Synthetic Cutoff Line Annotation */}
          {isFake && (
            <div className="absolute top-4 right-6 bg-rose-950/90 border border-rose-500/80 rounded-lg p-2 text-rose-300 text-[10px] font-mono flex items-center space-x-1.5 shadow-lg">
              <AlertTriangle className="h-3.5 w-3.5 text-rose-400 shrink-0" />
              <span>Vocoder Nyquist Cutoff Anomaly: &gt; 16 kHz Power Collapse</span>
            </div>
          )}
        </div>
      </div>

      {/* Voiceprint Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs">
          <span className="text-slate-400 block mb-1">Harmonic-to-Noise Ratio (HNR)</span>
          <div className="flex items-center justify-between">
            <span className="text-base font-bold font-mono text-white">
              {audioProfile.harmonicToNoiseRatio.toFixed(1)} dB
            </span>
            <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
              audioProfile.harmonicToNoiseRatio < 20 ? 'bg-rose-950 text-rose-400' : 'bg-emerald-950 text-emerald-400'
            }`}>
              {audioProfile.harmonicToNoiseRatio < 20 ? 'Neural Artifact' : 'Natural Sensor'}
            </span>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs">
          <span className="text-slate-400 block mb-1">Voice Timbre Consistency</span>
          <div className="flex items-center justify-between">
            <span className="text-base font-bold font-mono text-white">
              {audioProfile.voiceConsistency.toFixed(1)}%
            </span>
            <span className="text-[10px] text-cyan-400 font-mono">Formant F1-F4</span>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs">
          <span className="text-slate-400 block mb-1">Pitch Dynamic Micro-Tremors</span>
          <div className="flex items-center justify-between">
            <span className="text-base font-bold font-mono text-white">
              {audioProfile.pitchAnomaliesDetected ? 'Rigid (AI)' : 'Organic (Real)'}
            </span>
            <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
              audioProfile.pitchAnomaliesDetected ? 'bg-amber-950 text-amber-400' : 'bg-emerald-950 text-emerald-400'
            }`}>
              {audioProfile.pitchAnomaliesDetected ? 'Synthetic' : 'Biological'}
            </span>
          </div>
        </div>
      </div>

    </div>
  );
};
