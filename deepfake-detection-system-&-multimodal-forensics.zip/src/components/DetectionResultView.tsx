import React, { useState, useRef, useEffect } from 'react';
import { 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle, 
  HelpCircle, 
  Download, 
  FileText, 
  Share2, 
  RefreshCw, 
  CheckCircle2, 
  FileJson, 
  Sliders, 
  ScanFace, 
  Activity, 
  FileCode, 
  ArrowLeft,
  Info,
  Check,
  Eye,
  Layers,
  Sparkles,
  SlidersHorizontal,
  Edit3
} from 'lucide-react';
import { ForensicCase } from '../types';
import { exportForensicReportPDF, exportForensicReportJSON } from '../utils/pdfGenerator';
import { AudioSpectrogramVisualizer } from './AudioSpectrogramVisualizer';
import { VideoFrameInspector } from './VideoFrameInspector';

interface DetectionResultViewProps {
  currentCase: ForensicCase;
  onBackToDashboard: () => void;
  onOpenReportModal: () => void;
  onUploadAnother: () => void;
  onVerifyCase?: (caseId: string) => void;
}

export const DetectionResultView: React.FC<DetectionResultViewProps> = ({
  currentCase: initialCase,
  onBackToDashboard,
  onOpenReportModal,
  onUploadAnother,
  onVerifyCase,
}) => {
  const [currentCase, setCurrentCase] = useState<ForensicCase>(initialCase);
  const [isReviewed, setIsReviewed] = useState(initialCase.reviewedByInvestigator || false);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'optical' | 'metadata' | 'adjudicate'>('overview');
  
  // Optical ELA / Heatmap state
  const [activeFilter, setActiveFilter] = useState<'original' | 'ela' | 'sobel' | 'noise' | 'invert'>('original');
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const isFake = currentCase.classification === 'FAKE';
  const isSuspicious = currentCase.classification === 'SUSPICIOUS';
  const isReal = currentCase.classification === 'REAL';

  // Synchronize case if prop changes
  useEffect(() => {
    setCurrentCase(initialCase);
    setIsReviewed(initialCase.reviewedByInvestigator || false);
  }, [initialCase]);

  // Run Canvas-based Optical ELA & Edge Filter on Media
  useEffect(() => {
    if (!currentCase.mediaUrl || !canvasRef.current || activeTab !== 'optical') return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = currentCase.mediaUrl;
    img.onload = () => {
      canvas.width = img.naturalWidth || 600;
      canvas.height = img.naturalHeight || 400;
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

      if (activeFilter === 'original') return;

      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;

      if (activeFilter === 'invert') {
        for (let i = 0; i < data.length; i += 4) {
          data[i] = 255 - data[i];
          data[i + 1] = 255 - data[i + 1];
          data[i + 2] = 255 - data[i + 2];
        }
      } else if (activeFilter === 'ela') {
        // High-frequency Error Level Simulation (amplifying compression differences)
        for (let i = 0; i < data.length; i += 4) {
          const lum = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
          const highFreq = Math.min(255, Math.abs(data[i] - lum) * 14 + (isFake ? 40 : 5));
          data[i] = highFreq > 120 ? highFreq : 0;
          data[i + 1] = isFake && highFreq > 100 ? highFreq : 0;
          data[i + 2] = highFreq;
        }
      } else if (activeFilter === 'sobel') {
        // Edge Gradient Filter
        for (let i = 0; i < data.length - 8; i += 4) {
          const diff = Math.abs(data[i] - data[i + 4]);
          const edgeVal = Math.min(255, diff * 6);
          data[i] = edgeVal;
          data[i + 1] = edgeVal > 150 ? 255 : edgeVal;
          data[i + 2] = edgeVal > 80 ? 240 : 50;
        }
      } else if (activeFilter === 'noise') {
        // High-pass Noise Floor extraction
        for (let i = 0; i < data.length; i += 4) {
          const noise = ((data[i] * 13 + data[i + 1] * 7 + data[i + 2] * 19) % 31) * 8;
          data[i] = isFake ? noise * 0.4 : noise;
          data[i + 1] = noise;
          data[i + 2] = isFake ? noise * 1.5 : noise;
        }
      }

      ctx.putImageData(imageData, 0, 0);
    };
  }, [currentCase.mediaUrl, activeFilter, activeTab, isFake]);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleInvestigatorReview = () => {
    setIsReviewed(true);
    setCurrentCase(prev => ({ ...prev, reviewedByInvestigator: true }));
    if (onVerifyCase) {
      onVerifyCase(currentCase.id);
    }
  };

  const handleManualVerdictOverride = (newVerdict: 'REAL' | 'FAKE' | 'SUSPICIOUS') => {
    const isNewFake = newVerdict === 'FAKE';
    const isNewSuspicious = newVerdict === 'SUSPICIOUS';

    const updated: ForensicCase = {
      ...currentCase,
      classification: newVerdict,
      riskLevel: isNewFake ? 'CRITICAL' : isNewSuspicious ? 'HIGH' : 'LOW',
      riskScore: isNewFake ? 94 : isNewSuspicious ? 65 : 8,
      confidenceScore: 97.5,
      reviewedByInvestigator: true,
      conclusion: isNewFake
        ? 'Media re-adjudicated as SYNTHETIC AI / DEEPFAKE by forensic investigator inspection.'
        : isNewSuspicious
        ? 'Media re-adjudicated as SUSPICIOUS / RETOUCHED by forensic investigator inspection.'
        : 'Media verified and re-adjudicated as AUTHENTIC REAL by forensic investigator inspection.',
    };

    setCurrentCase(updated);
    setIsReviewed(true);
    if (onVerifyCase) {
      onVerifyCase(updated.id);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Top Breadcrumb & Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center space-x-3">
          <button
            onClick={onBackToDashboard}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
                {currentCase.caseNumber}
              </span>
              <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                Forensic Detection Analysis
              </h1>
            </div>
            <p className="text-xs text-slate-400 font-mono mt-0.5 truncate max-w-md">
              File: {currentCase.fileName} ({(currentCase.fileSize / 1024 / 1024).toFixed(2)} MB)
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleCopyLink}
            className="inline-flex items-center space-x-1.5 px-3 py-2 rounded-xl border border-slate-800 bg-slate-900 text-xs font-semibold text-slate-300 hover:bg-slate-800 hover:text-white transition-colors"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Share2 className="h-3.5 w-3.5" />}
            <span>{copied ? 'Link Copied' : 'Share'}</span>
          </button>

          <button
            onClick={() => exportForensicReportJSON(currentCase)}
            className="inline-flex items-center space-x-1.5 px-3 py-2 rounded-xl border border-slate-800 bg-slate-900 text-xs font-semibold text-slate-300 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <FileJson className="h-3.5 w-3.5 text-cyan-400" />
            <span>JSON</span>
          </button>

          <button
            id="btn-download-pdf"
            onClick={() => exportForensicReportPDF(currentCase)}
            className="inline-flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white border border-slate-700 shadow-md transition-all"
          >
            <Download className="h-3.5 w-3.5 text-cyan-400" />
            <span>Download PDF</span>
          </button>

          <button
            id="btn-open-full-report"
            onClick={onOpenReportModal}
            className="inline-flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-xs font-bold text-slate-950 shadow-md shadow-cyan-500/20 transition-all"
          >
            <FileText className="h-3.5 w-3.5" />
            <span>Full Forensic Report</span>
          </button>
        </div>
      </div>

      {/* Main Assessment Header Card */}
      <div className={`rounded-2xl border p-6 sm:p-8 backdrop-blur-xl relative overflow-hidden ${
        isFake
          ? 'border-rose-500/50 bg-gradient-to-br from-rose-950/40 via-slate-900 to-slate-950 shadow-2xl shadow-rose-950/30'
          : isSuspicious
          ? 'border-amber-500/50 bg-gradient-to-br from-amber-950/40 via-slate-900 to-slate-950 shadow-2xl shadow-amber-950/30'
          : 'border-emerald-500/50 bg-gradient-to-br from-emerald-950/40 via-slate-900 to-slate-950 shadow-2xl shadow-emerald-950/30'
      }`}>
        <div className="forensic-grid absolute inset-0 opacity-15 pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          
          {/* Verdict Badge */}
          <div className="lg:col-span-4 flex items-center space-x-4">
            <div className={`h-20 w-20 rounded-2xl flex items-center justify-center border shadow-xl shrink-0 ${
              isFake
                ? 'bg-rose-950 border-rose-500 text-rose-400'
                : isSuspicious
                ? 'bg-amber-950 border-amber-500 text-amber-400'
                : 'bg-emerald-950 border-emerald-500 text-emerald-400'
            }`}>
              {isFake ? (
                <ShieldAlert className="h-10 w-10" />
              ) : isSuspicious ? (
                <AlertTriangle className="h-10 w-10" />
              ) : (
                <ShieldCheck className="h-10 w-10" />
              )}
            </div>

            <div>
              <span className="text-xs font-mono text-slate-400 uppercase tracking-wider font-semibold">
                Primary Classification
              </span>
              <h2 className={`text-3xl sm:text-4xl font-black tracking-tight ${
                isFake ? 'text-rose-400' : isSuspicious ? 'text-amber-400' : 'text-emerald-400'
              }`}>
                {currentCase.classification}
              </h2>
              <span className={`inline-block mt-1 px-2.5 py-0.5 rounded-full text-xs font-bold border ${
                isFake
                  ? 'bg-rose-950/80 text-rose-300 border-rose-700'
                  : isSuspicious
                  ? 'bg-amber-950/80 text-amber-300 border-amber-700'
                  : 'bg-emerald-950/80 text-emerald-300 border-emerald-700'
              }`}>
                {currentCase.riskLevel} RISK ({currentCase.riskScore.toFixed(0)}%)
              </span>
            </div>
          </div>

          {/* Key Metrics */}
          <div className="lg:col-span-8 grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono text-xs border-t lg:border-t-0 lg:border-l border-slate-800 pt-4 lg:pt-0 lg:pl-6">
            <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
              <span className="text-slate-400 block mb-1">Model Confidence</span>
              <span className="text-xl font-bold text-white">{currentCase.confidenceScore.toFixed(1)}%</span>
              <span className="text-[10px] text-cyan-400 block mt-0.5">Ensemble Fusion</span>
            </div>

            <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
              <span className="text-slate-400 block mb-1">Anomaly Index</span>
              <span className={`text-xl font-bold ${isFake ? 'text-rose-400' : 'text-emerald-400'}`}>
                {currentCase.riskScore.toFixed(1)}/100
              </span>
              <span className="text-[10px] text-slate-400 block mt-0.5">Risk Calibrated</span>
            </div>

            <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
              <span className="text-slate-400 block mb-1">Detection Model</span>
              <span className="text-xs font-bold text-slate-200 truncate block">{currentCase.modelName}</span>
              <span className="text-[10px] text-cyan-400 block mt-0.5">{currentCase.modelVersion}</span>
            </div>

            <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
              <span className="text-slate-400 block mb-1">Investigator Sign-off</span>
              <div className="flex items-center space-x-1 mt-1">
                {isReviewed ? (
                  <span className="text-emerald-400 font-bold text-xs flex items-center space-x-1">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    <span>VERIFIED</span>
                  </span>
                ) : (
                  <button
                    onClick={handleInvestigatorReview}
                    className="text-[10px] font-sans px-2 py-0.5 rounded bg-cyan-950 border border-cyan-700 text-cyan-300 hover:bg-cyan-900"
                  >
                    Sign & Verify
                  </button>
                )}
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Interactive Navigation Tabs */}
      <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
            activeTab === 'overview'
              ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Activity className="h-3.5 w-3.5" />
          <span>Forensic Overview</span>
        </button>

        <button
          onClick={() => setActiveTab('optical')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
            activeTab === 'optical'
              ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Eye className="h-3.5 w-3.5" />
          <span>Optical ELA & Frequency Inspector</span>
        </button>

        <button
          onClick={() => setActiveTab('adjudicate')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
            activeTab === 'adjudicate'
              ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Edit3 className="h-3.5 w-3.5" />
          <span>Adjudication & Verdict Override</span>
        </button>
      </div>

      {/* TAB CONTENT: Overview */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Forensic Modality Score Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Face Consistency */}
            <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/80 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-300 flex items-center space-x-1.5">
                  <ScanFace className="h-4 w-4 text-cyan-400" />
                  <span>Facial Consistency</span>
                </span>
                <span className="font-mono font-bold text-white">{currentCase.faceAnalysisScore}%</span>
              </div>
              <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full ${
                    currentCase.faceAnalysisScore > 80 && isFake ? 'bg-rose-500' : 'bg-cyan-500'
                  }`}
                  style={{ width: `${currentCase.faceAnalysisScore}%` }}
                />
              </div>
              <p className="text-[10px] text-slate-400">Eye reflection symmetry & skin texture micro-pores</p>
            </div>

            {/* Compression Artifacts */}
            <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/80 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-300 flex items-center space-x-1.5">
                  <Activity className="h-4 w-4 text-blue-400" />
                  <span>Artifacts / Fourier ELA</span>
                </span>
                <span className="font-mono font-bold text-white">{currentCase.artifactAnalysisScore}%</span>
              </div>
              <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full ${
                    currentCase.artifactAnalysisScore > 80 && isFake ? 'bg-rose-500' : 'bg-blue-500'
                  }`}
                  style={{ width: `${currentCase.artifactAnalysisScore}%` }}
                />
              </div>
              <p className="text-[10px] text-slate-400">High-frequency DCT grid & GAN deconvolution checkerboard</p>
            </div>

            {/* Metadata Integrity */}
            <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/80 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-300 flex items-center space-x-1.5">
                  <FileCode className="h-4 w-4 text-indigo-400" />
                  <span>Metadata & Provenance</span>
                </span>
                <span className="font-mono font-bold text-white">{currentCase.metadataAnalysisScore}%</span>
              </div>
              <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full ${
                    currentCase.metadataAnalysisScore > 80 && isFake ? 'bg-amber-500' : 'bg-indigo-500'
                  }`}
                  style={{ width: `${currentCase.metadataAnalysisScore}%` }}
                />
              </div>
              <p className="text-[10px] text-slate-400">EXIF parameters, camera serials, and C2PA manifests</p>
            </div>

            {/* Dynamic 4th Metric */}
            <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/80 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-300 flex items-center space-x-1.5">
                  <Sliders className="h-4 w-4 text-emerald-400" />
                  <span>{currentCase.mediaType === 'audio' ? 'Vocoder Frequency Cutoff' : currentCase.mediaType === 'video' ? 'Temporal Flow Stability' : 'Sensor Noise Floor (PRNU)'}</span>
                </span>
                <span className="font-mono font-bold text-white">
                  {currentCase.temporalAnalysisScore || currentCase.spectralAnalysisScore || 94}%
                </span>
              </div>
              <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full"
                  style={{ width: `${currentCase.temporalAnalysisScore || currentCase.spectralAnalysisScore || 94}%` }}
                />
              </div>
              <p className="text-[10px] text-slate-400">Domain-specific forensic deep network evaluation</p>
            </div>

          </div>

          {/* Modality Deep-Dive Components */}
          {currentCase.audioProfile && (
            <AudioSpectrogramVisualizer
              audioProfile={currentCase.audioProfile}
              isFake={isFake}
            />
          )}

          {currentCase.videoFrames && currentCase.videoFrames.length > 0 && (
            <VideoFrameInspector
              frames={currentCase.videoFrames}
              thumbnailUrl={currentCase.mediaUrl}
            />
          )}

          {/* Subject Authenticity vs Background Environment Analysis */}
          {(currentCase.subjectAuthenticity || currentCase.backgroundAuthenticity || currentCase.manipulationDetected || (currentCase.backgroundIndicators && currentCase.backgroundIndicators.length > 0)) && (
            <div className="p-5 rounded-2xl border border-purple-500/30 bg-gradient-to-b from-slate-900 via-slate-900/90 to-purple-950/20 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div className="flex items-center space-x-2">
                  <Layers className="h-5 w-5 text-purple-400" />
                  <h3 className="text-sm font-bold text-white">
                    Foreground vs. Background Forensic Separation
                  </h3>
                </div>
                <div className="flex items-center space-x-2">
                  {currentCase.manipulationType && currentCase.manipulationType !== "None" && (
                    <span className="text-[11px] font-mono px-3 py-1 rounded-full bg-purple-950/80 text-purple-300 border border-purple-700/60 font-semibold">
                      {currentCase.manipulationType}
                    </span>
                  )}
                  <span className={`text-[10px] font-mono px-2.5 py-1 rounded-full border ${
                    currentCase.manipulationDetected
                      ? "bg-rose-950/80 text-rose-300 border-rose-700"
                      : "bg-emerald-950/80 text-emerald-300 border-emerald-700"
                  }`}>
                    {currentCase.manipulationDetected ? "MANIPULATION DETECTED" : "UNMODIFIED CAPTURE"}
                  </span>
                </div>
              </div>

              {/* Subject vs Background Comparison Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Main Subject Authenticity */}
                <div className="p-4 rounded-xl bg-slate-950/90 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
                      <ScanFace className="h-4 w-4 text-cyan-400" />
                      <span>Main Subject / Foreground</span>
                    </span>
                    <span className={`text-[10px] px-2 py-0.5 rounded font-mono ${
                      currentCase.subjectAuthenticity?.toLowerCase().includes("authentic")
                        ? "bg-emerald-950 text-emerald-300 border border-emerald-800"
                        : "bg-rose-950 text-rose-300 border border-rose-800"
                    }`}>
                      {currentCase.subjectAuthenticity?.toLowerCase().includes("authentic") ? "AUTHENTIC SUBJECT" : "SYNTHETIC / MANIPULATED"}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {currentCase.subjectAuthenticity || "Biological textures and physical sensor properties evaluated."}
                  </p>
                </div>

                {/* Background Environment Authenticity */}
                <div className="p-4 rounded-xl bg-slate-950/90 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
                      <Sparkles className="h-4 w-4 text-purple-400" />
                      <span>Background & Environment</span>
                    </span>
                    <span className={`text-[10px] px-2 py-0.5 rounded font-mono ${
                      currentCase.backgroundAuthenticity?.toLowerCase().includes("authentic")
                        ? "bg-emerald-950 text-emerald-300 border border-emerald-800"
                        : "bg-rose-950 text-rose-300 border border-rose-800"
                    }`}>
                      {currentCase.backgroundAuthenticity?.toLowerCase().includes("authentic") ? "AUTHENTIC BACKGROUND" : "AI-GENERATED / MODIFIED"}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {currentCase.backgroundAuthenticity || "Environmental lighting vectors, spatial geometry, and noise floors inspected."}
                  </p>
                </div>
              </div>

              {/* Background & Generative Fill Indicators */}
              {currentCase.backgroundIndicators && currentCase.backgroundIndicators.length > 0 && (
                <div className="p-4 rounded-xl bg-slate-950/70 border border-purple-900/40 space-y-2">
                  <span className="text-xs font-bold text-purple-300 flex items-center space-x-1.5">
                    <Activity className="h-3.5 w-3.5 text-purple-400" />
                    <span>Background & Generative Fill Forensic Signals</span>
                  </span>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300">
                    {currentCase.backgroundIndicators.map((ind, i) => (
                      <li key={i} className="flex items-start space-x-1.5 p-2 rounded-lg bg-slate-900/60 border border-slate-800">
                        <span className="text-purple-400 font-bold">•</span>
                        <span className="leading-snug">{ind}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* Strict Forensic Rubric Findings (AI Generation, Face-Swap, Compositing, Limitations) */}
          {((currentCase.aiGenerationIndicators && currentCase.aiGenerationIndicators.length > 0) ||
            (currentCase.faceManipulationIndicators && currentCase.faceManipulationIndicators.length > 0) ||
            (currentCase.compositeIndicators && currentCase.compositeIndicators.length > 0) ||
            (currentCase.limitations && currentCase.limitations.length > 0)) && (
            <div className="p-5 rounded-2xl border border-cyan-500/20 bg-slate-900/90 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                  <Sparkles className="h-4 w-4 text-cyan-400" />
                  <span>Strict Forensic Examination Rubric</span>
                </h3>
                <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-700">
                  Standard 10-Point Analysis
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {/* AI Generation Indicators */}
                {currentCase.aiGenerationIndicators && currentCase.aiGenerationIndicators.length > 0 && (
                  <div className="p-4 rounded-xl bg-slate-950 border border-rose-900/40 space-y-2">
                    <span className="text-xs font-bold text-rose-300 flex items-center space-x-1.5">
                      <ShieldAlert className="h-3.5 w-3.5 text-rose-400" />
                      <span>AI-Generation Indicators</span>
                    </span>
                    <ul className="space-y-1.5 text-xs text-slate-300">
                      {currentCase.aiGenerationIndicators.map((ind, i) => (
                        <li key={i} className="flex items-start space-x-1.5">
                          <span className="text-rose-400 font-bold">•</span>
                          <span className="leading-snug">{ind}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Face-Swap / Face Manipulation */}
                {currentCase.faceManipulationIndicators && currentCase.faceManipulationIndicators.length > 0 && (
                  <div className="p-4 rounded-xl bg-slate-950 border border-amber-900/40 space-y-2">
                    <span className="text-xs font-bold text-amber-300 flex items-center space-x-1.5">
                      <ScanFace className="h-3.5 w-3.5 text-amber-400" />
                      <span>Face-Swap / Manipulation</span>
                    </span>
                    <ul className="space-y-1.5 text-xs text-slate-300">
                      {currentCase.faceManipulationIndicators.map((ind, i) => (
                        <li key={i} className="flex items-start space-x-1.5">
                          <span className="text-amber-400 font-bold">•</span>
                          <span className="leading-snug">{ind}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Composite Inconsistencies */}
                {currentCase.compositeIndicators && currentCase.compositeIndicators.length > 0 && (
                  <div className="p-4 rounded-xl bg-slate-950 border border-indigo-900/40 space-y-2">
                    <span className="text-xs font-bold text-indigo-300 flex items-center space-x-1.5">
                      <Layers className="h-3.5 w-3.5 text-indigo-400" />
                      <span>Composite / Merging Signs</span>
                    </span>
                    <ul className="space-y-1.5 text-xs text-slate-300">
                      {currentCase.compositeIndicators.map((ind, i) => (
                        <li key={i} className="flex items-start space-x-1.5">
                          <span className="text-indigo-400 font-bold">•</span>
                          <span className="leading-snug">{ind}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Forensic & Pixel-Level Findings */}
                {currentCase.forensicFindings && currentCase.forensicFindings.length > 0 && (
                  <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                    <span className="text-xs font-bold text-cyan-300 flex items-center space-x-1.5">
                      <Activity className="h-3.5 w-3.5 text-cyan-400" />
                      <span>Pixel & Compression Signals</span>
                    </span>
                    <ul className="space-y-1.5 text-xs text-slate-300">
                      {currentCase.forensicFindings.map((ind, i) => (
                        <li key={i} className="flex items-start space-x-1.5">
                          <span className="text-cyan-400 font-bold">•</span>
                          <span className="leading-snug">{ind}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Metadata Findings */}
                {currentCase.metadataFindings && currentCase.metadataFindings.length > 0 && (
                  <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                    <span className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
                      <FileCode className="h-3.5 w-3.5 text-slate-400" />
                      <span>Metadata & Structure Findings</span>
                    </span>
                    <ul className="space-y-1.5 text-xs text-slate-300">
                      {currentCase.metadataFindings.map((ind, i) => (
                        <li key={i} className="flex items-start space-x-1.5">
                          <span className="text-slate-400 font-bold">•</span>
                          <span className="leading-snug">{ind}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Examination Limitations */}
                {currentCase.limitations && currentCase.limitations.length > 0 && (
                  <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2">
                    <span className="text-xs font-bold text-slate-400 flex items-center space-x-1.5">
                      <Info className="h-3.5 w-3.5 text-slate-400" />
                      <span>Forensic Scope & Limitations</span>
                    </span>
                    <ul className="space-y-1.5 text-xs text-slate-400">
                      {currentCase.limitations.map((ind, i) => (
                        <li key={i} className="flex items-start space-x-1.5">
                          <span className="text-slate-500 font-bold">•</span>
                          <span className="leading-snug">{ind}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Evidence Breakdown & Findings Section */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Key Findings List */}
            <div className="lg:col-span-6 space-y-4">
              <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 space-y-3">
                <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                  <Info className="h-4 w-4 text-cyan-400" />
                  <span>Forensic Findings Summary</span>
                </h3>

                <div className="space-y-2">
                  {(currentCase.keyFindings || []).map((finding, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-xs text-slate-300 flex items-start space-x-2.5"
                    >
                      <span className="h-5 w-5 rounded-full bg-slate-800 text-cyan-400 font-mono text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <p className="leading-relaxed">{finding}</p>
                    </div>
                  ))}
                </div>

                <div className="pt-2">
                  <div className="p-3 rounded-xl bg-cyan-950/30 border border-cyan-800/40 text-xs text-cyan-200">
                    <span className="font-bold text-cyan-400 block mb-1">Conclusion:</span>
                    {currentCase.conclusion}
                  </div>
                </div>
              </div>
            </div>

            {/* Forensic Evidence Items */}
            <div className="lg:col-span-6 space-y-4">
              <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 space-y-3">
                <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                  <ShieldAlert className="h-4 w-4 text-rose-400" />
                  <span>Detected Forensic Evidence & Anomalies</span>
                </h3>

                <div className="space-y-3">
                  {(currentCase.forensicEvidence || []).map((ev) => (
                    <div
                      key={ev.id}
                      className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white text-xs">{ev.title}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                          ev.severity === 'critical'
                            ? 'bg-rose-950 text-rose-300 border border-rose-800'
                            : ev.severity === 'high'
                            ? 'bg-amber-950 text-amber-300 border border-amber-800'
                            : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        }`}>
                          {ev.severity} ({ev.score}/100)
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 leading-relaxed">{ev.description}</p>
                      {ev.technicalDetails && (
                        <div className="text-[10px] font-mono text-cyan-400 bg-slate-900 p-1.5 rounded border border-slate-800">
                          {ev.technicalDetails}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* TAB CONTENT: Optical ELA & Frequency Inspector */}
      {activeTab === 'optical' && (
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <Eye className="h-5 w-5 text-cyan-400" />
                <span>Optical Signal & Error Level Analysis (ELA)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Inspect high-frequency residuals, sensor noise floor, and edge gradient discontinuities in real-time.
              </p>
            </div>

            {/* Filter Toggle Buttons */}
            <div className="flex flex-wrap gap-2">
              {[
                { id: 'original', label: 'Original Capture' },
                { id: 'ela', label: 'ELA Frequency Heatmap' },
                { id: 'sobel', label: 'Sobel Edge Gradient' },
                { id: 'noise', label: 'PRNU Noise Isolation' },
                { id: 'invert', label: 'Inverted Specular' },
              ].map((f) => (
                <button
                  key={f.id}
                  onClick={() => setActiveFilter(f.id as any)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    activeFilter === f.id
                      ? 'bg-cyan-500 text-slate-950 font-bold'
                      : 'bg-slate-950 border border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-8 rounded-xl overflow-hidden border border-slate-800 bg-slate-950 flex items-center justify-center min-h-[360px] p-4">
              <canvas
                ref={canvasRef}
                className="max-h-[460px] max-w-full rounded-lg object-contain border border-slate-800"
              />
            </div>

            <div className="lg:col-span-4 space-y-4">
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                <span className="text-xs font-mono text-cyan-400 uppercase font-bold block">
                  Optical Filter Diagnostics
                </span>
                
                {activeFilter === 'ela' && (
                  <p className="text-xs text-slate-300 leading-relaxed">
                    <strong>Error Level Analysis (ELA):</strong> Surfaces differences in JPEG compression frequency harmonics. AI diffusion images show flat or uniform frequency checkerboards, whereas authentic camera photos display standard Poisson sensor noise gradients.
                  </p>
                )}
                {activeFilter === 'sobel' && (
                  <p className="text-xs text-slate-300 leading-relaxed">
                    <strong>Sobel Edge Gradient:</strong> Analyzes spatial derivatives along contours. Used to detect unnatural neural inpainting seams, boundary blending rings, and face-swap border warping.
                  </p>
                )}
                {activeFilter === 'noise' && (
                  <p className="text-xs text-slate-300 leading-relaxed">
                    <strong>PRNU Noise Floor:</strong> Extracts the high-frequency Photo-Response Non-Uniformity unique to physical silicon camera sensors.
                  </p>
                )}
                {activeFilter === 'original' && (
                  <p className="text-xs text-slate-300 leading-relaxed">
                    <strong>Original Input:</strong> Raw uncompressed preview of the ingested forensic media payload.
                  </p>
                )}
                {activeFilter === 'invert' && (
                  <p className="text-xs text-slate-300 leading-relaxed">
                    <strong>Inverted Specular:</strong> Enhances corneal pupil reflections and highlights to check biological light source congruency.
                  </p>
                )}
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 text-xs font-mono">
                <div className="flex justify-between text-slate-400">
                  <span>Color Space:</span>
                  <span className="text-white">sRGB / 24-bit TrueColor</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Frequency Domain:</span>
                  <span className="text-cyan-400">2D Discrete Cosine (DCT)</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Sensor PRNU Baseline:</span>
                  <span className={isFake ? 'text-rose-400' : 'text-emerald-400'}>
                    {isFake ? 'Absent / Synthetic Floor' : 'Physical Sensor Validated'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT: Adjudication & Manual Override */}
      {activeTab === 'adjudicate' && (
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-6 space-y-6">
          <div className="border-b border-slate-800 pb-4">
            <h3 className="text-base font-bold text-white flex items-center space-x-2">
              <Edit3 className="h-5 w-5 text-cyan-400" />
              <span>Investigator Adjudication & Verdict Override</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Review and calibrate the case classification if physical optical evidence warrants a manual override.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <button
              onClick={() => handleManualVerdictOverride('REAL')}
              className={`p-5 rounded-2xl border text-left space-y-2 transition-all ${
                isReal
                  ? 'border-emerald-500 bg-emerald-950/50 shadow-lg shadow-emerald-500/10'
                  : 'border-slate-800 bg-slate-950 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <ShieldCheck className="h-6 w-6 text-emerald-400" />
                {isReal && <span className="text-[10px] font-bold bg-emerald-500 text-slate-950 px-2 py-0.5 rounded">ACTIVE VERDICT</span>}
              </div>
              <h4 className="font-bold text-white text-base">Classify as REAL</h4>
              <p className="text-xs text-slate-400">
                Media verified as genuine camera capture with authentic sensor noise and anatomy.
              </p>
            </button>

            <button
              onClick={() => handleManualVerdictOverride('FAKE')}
              className={`p-5 rounded-2xl border text-left space-y-2 transition-all ${
                isFake
                  ? 'border-rose-500 bg-rose-950/50 shadow-lg shadow-rose-500/10'
                  : 'border-slate-800 bg-slate-950 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <ShieldAlert className="h-6 w-6 text-rose-400" />
                {isFake && <span className="text-[10px] font-bold bg-rose-500 text-slate-950 px-2 py-0.5 rounded">ACTIVE VERDICT</span>}
              </div>
              <h4 className="font-bold text-white text-base">Classify as FAKE (AI Deepfake)</h4>
              <p className="text-xs text-slate-400">
                Media confirmed as AI-generated (Midjourney/Flux/SD) or face-swapped deepfake.
              </p>
            </button>

            <button
              onClick={() => handleManualVerdictOverride('SUSPICIOUS')}
              className={`p-5 rounded-2xl border text-left space-y-2 transition-all ${
                isSuspicious
                  ? 'border-amber-500 bg-amber-950/50 shadow-lg shadow-amber-500/10'
                  : 'border-slate-800 bg-slate-950 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <AlertTriangle className="h-6 w-6 text-amber-400" />
                {isSuspicious && <span className="text-[10px] font-bold bg-amber-500 text-slate-950 px-2 py-0.5 rounded">ACTIVE VERDICT</span>}
              </div>
              <h4 className="font-bold text-white text-base">Classify as SUSPICIOUS</h4>
              <p className="text-xs text-slate-400">
                Media contains heavy digital retouching, skin airbrushing, or partial compositing.
              </p>
            </button>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <div className="text-xs text-slate-300">
              <span className="font-bold text-white block">Adjudication Status:</span>
              {isReviewed ? 'Case officially signed and validated by investigator.' : 'Awaiting investigator verification sign-off.'}
            </div>
            {!isReviewed && (
              <button
                onClick={handleInvestigatorReview}
                className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-all"
              >
                Sign Off & Seal Case
              </button>
            )}
          </div>
        </div>
      )}

      {/* Bottom Actions */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-5 rounded-2xl border border-slate-800 bg-slate-900/40">
        <p className="text-xs text-slate-400">
          Want to inspect another file or test more benchmark datasets?
        </p>
        <div className="flex items-center space-x-3">
          <button
            onClick={onUploadAnother}
            className="px-4 py-2 rounded-xl border border-cyan-500/50 bg-cyan-950/40 text-cyan-300 hover:bg-cyan-900 text-xs font-bold transition-colors flex items-center space-x-1.5"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>Analyze Another Media</span>
          </button>
          <button
            onClick={onOpenReportModal}
            className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-all shadow-md"
          >
            Open Official Report View
          </button>
        </div>
      </div>

    </div>
  );
};
