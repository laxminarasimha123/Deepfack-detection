import React from 'react';
import { 
  FileCheck2, 
  ShieldCheck, 
  AlertTriangle, 
  HelpCircle, 
  Upload, 
  History, 
  FileSpreadsheet, 
  Layers, 
  ArrowUpRight, 
  Activity,
  Plus
} from 'lucide-react';
import { ForensicCase } from '../types';

interface DashboardStatsProps {
  cases: ForensicCase[];
  onUploadClick: () => void;
  onViewHistory: () => void;
  onSelectCase: (c: ForensicCase) => void;
  onQuickBenchmark: () => void;
}

export const DashboardStats: React.FC<DashboardStatsProps> = ({
  cases,
  onUploadClick,
  onViewHistory,
  onSelectCase,
  onQuickBenchmark,
}) => {
  const total = cases.length;
  const realCount = cases.filter((c) => c.classification === 'REAL').length;
  const fakeCount = cases.filter((c) => c.classification === 'FAKE').length;
  const suspiciousCount = cases.filter((c) => c.classification === 'SUSPICIOUS').length;
  const inconclusiveCount = cases.filter((c) => c.classification === 'INCONCLUSIVE').length;

  const recentCases = cases.slice(0, 5);

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Dashboard Top Header & Quick Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
            Forensic Detection Workspace
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time media authentication telemetry, risk classifications, and case files.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={onQuickBenchmark}
            className="inline-flex items-center space-x-1.5 px-3.5 py-2 rounded-xl border border-slate-700 bg-slate-900 text-xs font-semibold text-slate-300 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <Layers className="h-3.5 w-3.5 text-cyan-400" />
            <span>Benchmark Library</span>
          </button>

          <button
            id="dash-quick-upload-btn"
            onClick={onUploadClick}
            className="inline-flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-xs font-bold text-slate-950 shadow-md shadow-cyan-500/20 transition-all"
          >
            <Plus className="h-4 w-4" />
            <span>Upload New Media</span>
          </button>
        </div>
      </div>

      {/* 4 Main Requirement Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        
        {/* Total Analyses */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 shadow-lg relative overflow-hidden group hover:border-cyan-500/40 transition-colors">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Analyses</p>
              <h3 className="text-3xl font-extrabold text-white mt-2 font-mono">{total}</h3>
              <p className="text-[11px] text-slate-400 mt-1 flex items-center space-x-1">
                <span className="text-cyan-400 font-semibold">100%</span>
                <span>cases logged in registry</span>
              </p>
            </div>
            <div className="h-11 w-11 rounded-xl bg-cyan-950/80 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <FileSpreadsheet className="h-5 w-5" />
            </div>
          </div>
          <div className="h-1 w-full bg-slate-800 absolute bottom-0 inset-x-0">
            <div className="h-full bg-cyan-500 w-full" />
          </div>
        </div>

        {/* Real Media */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 shadow-lg relative overflow-hidden group hover:border-emerald-500/40 transition-colors">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">Real Media</p>
              <h3 className="text-3xl font-extrabold text-white mt-2 font-mono text-emerald-400">{realCount}</h3>
              <p className="text-[11px] text-slate-400 mt-1">
                {total > 0 ? Math.round((realCount / total) * 100) : 0}% Verified Authentic
              </p>
            </div>
            <div className="h-11 w-11 rounded-xl bg-emerald-950/80 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <ShieldCheck className="h-5 w-5" />
            </div>
          </div>
          <div className="h-1 w-full bg-slate-800 absolute bottom-0 inset-x-0">
            <div 
              className="h-full bg-emerald-500 transition-all duration-500" 
              style={{ width: `${total > 0 ? (realCount / total) * 100 : 0}%` }} 
            />
          </div>
        </div>

        {/* Deepfakes Detected */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 shadow-lg relative overflow-hidden group hover:border-rose-500/40 transition-colors">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-semibold text-rose-400 uppercase tracking-wider">Deepfakes</p>
              <h3 className="text-3xl font-extrabold text-white mt-2 font-mono text-rose-400">{fakeCount}</h3>
              <p className="text-[11px] text-slate-400 mt-1">
                {total > 0 ? Math.round((fakeCount / total) * 100) : 0}% High-Risk Manipulated
              </p>
            </div>
            <div className="h-11 w-11 rounded-xl bg-rose-950/80 border border-rose-500/30 flex items-center justify-center text-rose-400">
              <AlertTriangle className="h-5 w-5" />
            </div>
          </div>
          <div className="h-1 w-full bg-slate-800 absolute bottom-0 inset-x-0">
            <div 
              className="h-full bg-rose-500 transition-all duration-500" 
              style={{ width: `${total > 0 ? (fakeCount / total) * 100 : 0}%` }} 
            />
          </div>
        </div>

        {/* Suspicious / Inconclusive */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 shadow-lg relative overflow-hidden group hover:border-amber-500/40 transition-colors">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-semibold text-amber-400 uppercase tracking-wider">Suspicious</p>
              <h3 className="text-3xl font-extrabold text-white mt-2 font-mono text-amber-400">{suspiciousCount}</h3>
              <p className="text-[11px] text-slate-400 mt-1">
                {inconclusiveCount} Inconclusive case(s)
              </p>
            </div>
            <div className="h-11 w-11 rounded-xl bg-amber-950/80 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <HelpCircle className="h-5 w-5" />
            </div>
          </div>
          <div className="h-1 w-full bg-slate-800 absolute bottom-0 inset-x-0">
            <div 
              className="h-full bg-amber-500 transition-all duration-500" 
              style={{ width: `${total > 0 ? (suspiciousCount / total) * 100 : 0}%` }} 
            />
          </div>
        </div>

      </div>

      {/* Quick Launch & Modality Shortcuts */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div 
          onClick={onUploadClick}
          className="p-4 rounded-xl border border-slate-800 bg-gradient-to-br from-slate-900 to-slate-950 hover:border-cyan-500/50 cursor-pointer transition-all space-y-2 group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-cyan-400 font-semibold uppercase">Image Engine</span>
            <ArrowUpRight className="h-4 w-4 text-slate-400 group-hover:text-cyan-400 transition-colors" />
          </div>
          <h4 className="font-bold text-white text-sm">Analyze Image</h4>
          <p className="text-xs text-slate-400">Face ROI, Error Level Analysis (ELA), Sensor PRNU noise.</p>
        </div>

        <div 
          onClick={onUploadClick}
          className="p-4 rounded-xl border border-slate-800 bg-gradient-to-br from-slate-900 to-slate-950 hover:border-blue-500/50 cursor-pointer transition-all space-y-2 group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-blue-400 font-semibold uppercase">Video Engine</span>
            <ArrowUpRight className="h-4 w-4 text-slate-400 group-hover:text-blue-400 transition-colors" />
          </div>
          <h4 className="font-bold text-white text-sm">Analyze Video</h4>
          <p className="text-xs text-slate-400">Temporal optical flow, frame-by-frame deepfake scanning.</p>
        </div>

        <div 
          onClick={onUploadClick}
          className="p-4 rounded-xl border border-slate-800 bg-gradient-to-br from-slate-900 to-slate-950 hover:border-indigo-500/50 cursor-pointer transition-all space-y-2 group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-indigo-400 font-semibold uppercase">Audio Engine</span>
            <ArrowUpRight className="h-4 w-4 text-slate-400 group-hover:text-indigo-400 transition-colors" />
          </div>
          <h4 className="font-bold text-white text-sm">Analyze Audio Speech</h4>
          <p className="text-xs text-slate-400">Mel-Spectrogram, neural vocoder frequency cutoff test.</p>
        </div>

        <div 
          onClick={onUploadClick}
          className="p-4 rounded-xl border border-slate-800 bg-gradient-to-br from-slate-900 to-slate-950 hover:border-emerald-500/50 cursor-pointer transition-all space-y-2 group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-emerald-400 font-semibold uppercase">Multimodal Engine</span>
            <ArrowUpRight className="h-4 w-4 text-slate-400 group-hover:text-emerald-400 transition-colors" />
          </div>
          <h4 className="font-bold text-white text-sm">Multimodal Fusion</h4>
          <p className="text-xs text-slate-400">Audio-Visual lip synchronization, cross-modal evidence.</p>
        </div>
      </div>

      {/* Recent Analyses Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div>
            <h3 className="font-bold text-white text-base">Recent Forensic Investigations</h3>
            <p className="text-xs text-slate-400">Latest media submitted for deepfake forensic evaluation</p>
          </div>
          <button
            onClick={onViewHistory}
            className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center space-x-1"
          >
            <span>View Full Case History</span>
            <History className="h-3.5 w-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 text-slate-400 font-mono border-b border-slate-800 uppercase tracking-wider">
              <tr>
                <th className="px-6 py-3.5">Case ID</th>
                <th className="px-6 py-3.5">Media File</th>
                <th className="px-6 py-3.5">Modality</th>
                <th className="px-6 py-3.5">Classification</th>
                <th className="px-6 py-3.5">Confidence</th>
                <th className="px-6 py-3.5">Risk Level</th>
                <th className="px-6 py-3.5">Date</th>
                <th className="px-6 py-3.5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {recentCases.map((c) => {
                let badgeClass = 'bg-rose-950 text-rose-400 border-rose-800';
                if (c.classification === 'REAL') badgeClass = 'bg-emerald-950 text-emerald-400 border-emerald-800';
                if (c.classification === 'SUSPICIOUS') badgeClass = 'bg-amber-950 text-amber-400 border-amber-800';
                if (c.classification === 'INCONCLUSIVE') badgeClass = 'bg-slate-800 text-slate-300 border-slate-700';

                return (
                  <tr 
                    key={c.id} 
                    className="hover:bg-slate-800/40 transition-colors cursor-pointer group"
                    onClick={() => onSelectCase(c)}
                  >
                    <td className="px-6 py-4 font-mono font-semibold text-cyan-400">
                      {c.caseNumber}
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-medium text-slate-200 truncate max-w-[200px]">
                        {c.fileName}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {(c.fileSize / 1024 / 1024).toFixed(2)} MB
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-block px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-slate-800 text-slate-300 border border-slate-700">
                        {c.mediaType}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold border ${badgeClass}`}>
                        {c.classification}
                      </span>
                    </td>
                    <td className="px-6 py-4 font-mono font-medium text-slate-300">
                      {c.confidenceScore.toFixed(1)}%
                    </td>
                    <td className="px-6 py-4">
                      <span className={`text-xs font-semibold ${
                        c.riskLevel === 'CRITICAL' || c.riskLevel === 'HIGH'
                          ? 'text-rose-400'
                          : c.riskLevel === 'MEDIUM'
                          ? 'text-amber-400'
                          : 'text-emerald-400'
                      }`}>
                        {c.riskLevel} ({c.riskScore.toFixed(0)}%)
                      </span>
                    </td>
                    <td className="px-6 py-4 text-slate-400 text-[11px]">
                      {new Date(c.createdAt).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectCase(c);
                        }}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 text-slate-300 text-xs font-medium transition-all"
                      >
                        Inspect Result
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
