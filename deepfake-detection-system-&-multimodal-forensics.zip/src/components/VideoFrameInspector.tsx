import React, { useState } from 'react';
import { Film, AlertTriangle, CheckCircle, Eye, Play, Pause, ChevronLeft, ChevronRight } from 'lucide-react';
import { VideoFrameAnomaly } from '../types';

interface VideoFrameInspectorProps {
  frames: VideoFrameAnomaly[];
  thumbnailUrl?: string;
}

export const VideoFrameInspector: React.FC<VideoFrameInspectorProps> = ({
  frames,
  thumbnailUrl,
}) => {
  const [selectedFrameIndex, setSelectedFrameIndex] = useState(0);
  const activeFrame = frames[selectedFrameIndex] || frames[0];

  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 space-y-5">
      
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div className="flex items-center space-x-2">
          <div className="h-8 w-8 rounded-lg bg-blue-950 border border-blue-500/30 flex items-center justify-center text-blue-400">
            <Film className="h-4 w-4" />
          </div>
          <div>
            <h3 className="font-bold text-white text-sm">Temporal & Frame-by-Frame Inspector</h3>
            <p className="text-[11px] text-slate-400 font-mono">Inter-Frame Optical Flow Velocity & Facial Landmark Jitter</p>
          </div>
        </div>

        <span className="text-xs font-mono text-cyan-400 bg-cyan-950/80 px-2.5 py-1 rounded-full border border-cyan-800">
          {frames.length} Keyframes Extracted
        </span>
      </div>

      {/* Frame Viewer + Inspection Canvas */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
        
        {/* Frame Canvas */}
        <div className="md:col-span-7">
          <div className="relative rounded-xl overflow-hidden border border-slate-800 bg-slate-950 aspect-video flex items-center justify-center">
            {thumbnailUrl ? (
              <img
                src={thumbnailUrl}
                alt={`Frame ${activeFrame?.frameNumber}`}
                className="w-full h-full object-cover filter brightness-95"
              />
            ) : (
              <div className="text-slate-500 font-mono text-xs">Frame Preview Stream</div>
            )}

            {/* Bounding Box on active frame if fake */}
            {activeFrame?.prediction !== 'REAL' && (
              <div className="absolute top-[25%] left-[30%] w-[40%] h-[50%] border-2 border-dashed border-rose-500 rounded bg-rose-500/15 pointer-events-none">
                <div className="absolute -top-3 left-2 bg-rose-950 text-rose-300 text-[9px] font-mono px-1 py-0.5 rounded border border-rose-600">
                  {activeFrame?.anomalyType || 'Temporal Anomaly'}
                </div>
              </div>
            )}

            {/* Frame Metadata Badge */}
            <div className="absolute bottom-2 left-2 right-2 flex justify-between items-center text-[10px] font-mono bg-slate-950/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-800">
              <span className="text-slate-300">
                FRAME #{activeFrame?.frameNumber} • TIME: {activeFrame?.timestamp}
              </span>
              <span className={`font-bold ${
                activeFrame?.prediction === 'REAL' ? 'text-emerald-400' : 'text-rose-400'
              }`}>
                {activeFrame?.prediction} ({activeFrame?.confidence.toFixed(1)}%)
              </span>
            </div>
          </div>
        </div>

        {/* Selected Frame Diagnostics */}
        <div className="md:col-span-5 space-y-3 font-mono text-xs">
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Frame Status:</span>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                activeFrame?.prediction === 'REAL'
                  ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                  : 'bg-rose-950 text-rose-400 border-rose-800'
              }`}>
                {activeFrame?.prediction}
              </span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-slate-400">Temporal Risk:</span>
              <span className="font-bold text-white">{activeFrame?.riskScore.toFixed(1)}%</span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-slate-400">Facial Detection:</span>
              <span className="text-emerald-400 flex items-center space-x-1">
                <CheckCircle className="h-3.5 w-3.5" />
                <span>68 Landmark Points</span>
              </span>
            </div>

            <div className="border-t border-slate-800/80 pt-2">
              <span className="text-slate-400 block mb-1 text-[11px]">Forensic Observation:</span>
              <p className="text-slate-300 text-[11px] font-sans leading-relaxed">
                {activeFrame?.notes}
              </p>
            </div>
          </div>
        </div>

      </div>

      {/* Frame Navigation Timeline Bar */}
      <div className="space-y-2">
        <div className="flex justify-between text-xs font-mono text-slate-400">
          <span>Keyframe Timeline Sequence</span>
          <span>Click to Inspect Target Frame</span>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {frames.map((frame, idx) => (
            <button
              key={idx}
              onClick={() => setSelectedFrameIndex(idx)}
              className={`p-2.5 rounded-xl border text-left transition-all ${
                selectedFrameIndex === idx
                  ? 'border-cyan-500 bg-cyan-950/40 ring-1 ring-cyan-500'
                  : 'border-slate-800 bg-slate-950 hover:bg-slate-900'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-white">
                  Frame #{frame.frameNumber}
                </span>
                <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded border ${
                  frame.prediction === 'REAL'
                    ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                    : 'bg-rose-950 text-rose-400 border-rose-800'
                }`}>
                  {frame.prediction}
                </span>
              </div>
              <div className="text-[10px] text-slate-400 font-mono mt-1">
                {frame.timestamp} • Risk: {frame.riskScore.toFixed(0)}%
              </div>
            </button>
          ))}
        </div>
      </div>

    </div>
  );
};
