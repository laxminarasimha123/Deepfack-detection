import React from 'react';
import { X, Layers, Sparkles, CheckCircle2, ShieldAlert, ArrowRight } from 'lucide-react';
import { BenchmarkSample } from '../types';
import { SAMPLE_BENCHMARKS } from '../data/sampleMedia';

interface BenchmarkLibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectSample: (sample: BenchmarkSample) => void;
}

export const BenchmarkLibraryModal: React.FC<BenchmarkLibraryModalProps> = ({
  isOpen,
  onClose,
  onSelectSample,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6">
      <div className="relative w-full max-w-5xl rounded-2xl border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center space-x-3">
            <div className="h-9 w-9 rounded-xl bg-cyan-950 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
              <Layers className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                Preloaded Forensic Benchmark Test Library
              </h2>
              <p className="text-xs text-slate-400">
                Ground-truth authentic vs synthetic datasets for evaluating multimodal detection accuracy.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {SAMPLE_BENCHMARKS.map((sample) => (
              <div
                key={sample.id}
                className="rounded-xl border border-slate-800 bg-slate-950/80 p-4 flex flex-col justify-between hover:border-cyan-500/50 transition-all group"
              >
                <div className="space-y-3">
                  <div className="relative rounded-lg overflow-hidden aspect-video border border-slate-800 bg-slate-900">
                    <img
                      src={sample.thumbnailUrl}
                      alt={sample.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <span className={`absolute top-2 left-2 px-2 py-0.5 rounded text-[10px] font-bold border backdrop-blur-md ${
                      sample.expectedClassification === 'FAKE'
                        ? 'bg-rose-950/80 text-rose-300 border-rose-700'
                        : sample.expectedClassification === 'SUSPICIOUS'
                        ? 'bg-amber-950/80 text-amber-300 border-amber-700'
                        : 'bg-emerald-950/80 text-emerald-300 border-emerald-700'
                    }`}>
                      {sample.expectedClassification}
                    </span>
                    <span className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded text-[9px] font-mono uppercase bg-slate-950/80 text-slate-300 border border-slate-800">
                      {sample.mediaType}
                    </span>
                  </div>

                  <div>
                    <h4 className="font-bold text-white text-sm group-hover:text-cyan-300 transition-colors">
                      {sample.title}
                    </h4>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed line-clamp-2">
                      {sample.description}
                    </p>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                  <span className="text-[11px] font-mono text-cyan-400">
                    {sample.manipulationType}
                  </span>
                  <button
                    onClick={() => {
                      onSelectSample(sample);
                      onClose();
                    }}
                    className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-colors flex items-center space-x-1"
                  >
                    <span>Load Sample</span>
                    <ArrowRight className="h-3 w-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
