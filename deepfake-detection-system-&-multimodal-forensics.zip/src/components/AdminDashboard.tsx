import React, { useState } from 'react';
import { 
  Users, 
  Cpu, 
  BarChart3, 
  ShieldAlert, 
  Sliders, 
  CheckCircle, 
  AlertTriangle, 
  Activity, 
  Lock, 
  Sparkles, 
  Database,
  ArrowUpRight,
  UserCheck
} from 'lucide-react';
import { User, ModelPerformanceMetric, ForensicCase, UserRole } from '../types';

interface AdminDashboardProps {
  users: User[];
  models: ModelPerformanceMetric[];
  cases: ForensicCase[];
  onUpdateUserRole: (userId: string, role: UserRole) => void;
  onToggleUserStatus: (userId: string) => void;
  onSelectCase: (c: ForensicCase) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  users,
  models,
  cases,
  onUpdateUserRole,
  onToggleUserStatus,
  onSelectCase,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'models' | 'users' | 'high_risk'>('overview');

  const totalCases = cases.length;
  const fakeCount = cases.filter((c) => c.classification === 'FAKE').length;
  const suspiciousCount = cases.filter((c) => c.classification === 'SUSPICIOUS').length;
  const highRiskCases = cases.filter((c) => c.riskLevel === 'CRITICAL' || c.riskLevel === 'HIGH');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      
      {/* Admin Center Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2 py-0.5 rounded bg-indigo-950 text-indigo-400 border border-indigo-800 text-[10px] font-mono uppercase font-bold">
              Administrator Console
            </span>
            <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              Forensic System Telemetry & Model Ops
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Global media verification metrics, model evaluation scores (F1, ROC-AUC, FPR/FNR), and user access controls.
          </p>
        </div>

        {/* Engine Status Badge */}
        <div className="flex items-center space-x-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs">
          <div className="h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="text-slate-300 font-mono">Forensic Node: <strong className="text-white">US-CENTRAL-01</strong></span>
        </div>
      </div>

      {/* Admin Navigation Tabs */}
      <div className="flex space-x-2 border-b border-slate-800 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('overview')}
          className={`pb-3 px-3 transition-colors border-b-2 flex items-center space-x-2 ${
            activeTab === 'overview'
              ? 'border-indigo-500 text-indigo-400 font-bold'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <BarChart3 className="h-4 w-4" />
          <span>System Overview</span>
        </button>

        <button
          onClick={() => setActiveTab('models')}
          className={`pb-3 px-3 transition-colors border-b-2 flex items-center space-x-2 ${
            activeTab === 'models'
              ? 'border-indigo-500 text-indigo-400 font-bold'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <Cpu className="h-4 w-4" />
          <span>Model Benchmark Metrics</span>
        </button>

        <button
          onClick={() => setActiveTab('high_risk')}
          className={`pb-3 px-3 transition-colors border-b-2 flex items-center space-x-2 ${
            activeTab === 'high_risk'
              ? 'border-rose-500 text-rose-400 font-bold'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <ShieldAlert className="h-4 w-4" />
          <span>High-Risk Queue ({highRiskCases.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('users')}
          className={`pb-3 px-3 transition-colors border-b-2 flex items-center space-x-2 ${
            activeTab === 'users'
              ? 'border-indigo-500 text-indigo-400 font-bold'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <Users className="h-4 w-4" />
          <span>User & RBAC Controls ({users.length})</span>
        </button>
      </div>

      {/* Tab 1: System Overview */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          
          {/* Top Admin Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl border border-slate-800 bg-slate-900/80 space-y-2">
              <span className="text-xs font-mono text-slate-400 uppercase font-semibold">Registered Users</span>
              <h3 className="text-3xl font-extrabold text-white font-mono">{users.length}</h3>
              <p className="text-[11px] text-slate-400">{users.filter((u) => u.status === 'active').length} active examiners</p>
            </div>

            <div className="p-5 rounded-2xl border border-slate-800 bg-slate-900/80 space-y-2">
              <span className="text-xs font-mono text-cyan-400 uppercase font-semibold">Total Ingested Files</span>
              <h3 className="text-3xl font-extrabold text-white font-mono">{totalCases}</h3>
              <p className="text-[11px] text-cyan-300">100% evaluated across 4 modalities</p>
            </div>

            <div className="p-5 rounded-2xl border border-slate-800 bg-slate-900/80 space-y-2">
              <span className="text-xs font-mono text-rose-400 uppercase font-semibold">Flagged Deepfakes</span>
              <h3 className="text-3xl font-extrabold text-rose-400 font-mono">{fakeCount}</h3>
              <p className="text-[11px] text-slate-400">+{suspiciousCount} under human review</p>
            </div>

            <div className="p-5 rounded-2xl border border-slate-800 bg-slate-900/80 space-y-2">
              <span className="text-xs font-mono text-emerald-400 uppercase font-semibold">Average Pipeline Latency</span>
              <h3 className="text-3xl font-extrabold text-white font-mono">420 ms</h3>
              <p className="text-[11px] text-emerald-400">Optimal throughput</p>
            </div>
          </div>

          {/* Modality Ingestion Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/70 space-y-4">
              <h3 className="font-bold text-white text-sm">Media Modality Volume Distribution</h3>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-300">Image Forensics (JPEG, PNG, WEBP)</span>
                    <span className="font-mono text-cyan-400 font-bold">
                      {cases.filter((c) => c.mediaType === 'image').length} cases
                    </span>
                  </div>
                  <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-cyan-500 w-[55%]" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-300">Video Forensics (MP4, MOV)</span>
                    <span className="font-mono text-blue-400 font-bold">
                      {cases.filter((c) => c.mediaType === 'video').length} cases
                    </span>
                  </div>
                  <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 w-[25%]" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-300">Audio Speech (WAV, MP3)</span>
                    <span className="font-mono text-indigo-400 font-bold">
                      {cases.filter((c) => c.mediaType === 'audio').length} cases
                    </span>
                  </div>
                  <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-indigo-500 w-[15%]" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-300">Multimodal Fusion (AV Sync)</span>
                    <span className="font-mono text-emerald-400 font-bold">
                      {cases.filter((c) => c.mediaType === 'multimodal').length} cases
                    </span>
                  </div>
                  <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500 w-[10%]" />
                  </div>
                </div>
              </div>
            </div>

            {/* Architecture Overview */}
            <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/70 space-y-4">
              <h3 className="font-bold text-white text-sm">Forensic Defense Configuration</h3>
              <div className="space-y-2.5 font-mono text-xs">
                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Primary Vision Model:</span>
                  <span className="text-cyan-400 font-bold">DeepForensic Vision 3.7</span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Video Optical Flow Network:</span>
                  <span className="text-blue-400 font-bold">TemporalConsistency-Net 4D</span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Audio Spectrogram Classifier:</span>
                  <span className="text-indigo-400 font-bold">SpectralGuard v2.8</span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Gemini Reasoning Engine:</span>
                  <span className="text-emerald-400 font-bold">gemini-3.7-flash</span>
                </div>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* Tab 2: Model Benchmark Metrics (Section 25) */}
      {activeTab === 'models' && (
        <div className="space-y-6">
          <div className="rounded-2xl border border-slate-800 bg-slate-900/60 overflow-hidden shadow-xl">
            <div className="p-5 border-b border-slate-800 flex justify-between items-center">
              <div>
                <h3 className="font-bold text-white text-base">Model Performance Evaluation Registry</h3>
                <p className="text-xs text-slate-400">
                  Comprehensive benchmark test scores across FaceForensics++, DFDC, Celeb-DF, and ASVspoof datasets.
                </p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 font-mono uppercase tracking-wider border-b border-slate-800">
                  <tr>
                    <th className="px-5 py-3.5">Model / Architecture</th>
                    <th className="px-5 py-3.5">Modality</th>
                    <th className="px-5 py-3.5">Accuracy</th>
                    <th className="px-5 py-3.5">Precision</th>
                    <th className="px-5 py-3.5">Recall</th>
                    <th className="px-5 py-3.5">F1 Score</th>
                    <th className="px-5 py-3.5">FPR / FNR</th>
                    <th className="px-5 py-3.5">ROC-AUC</th>
                    <th className="px-5 py-3.5">Latency</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {models.map((m) => (
                    <tr key={m.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="px-5 py-4">
                        <div className="font-bold text-white text-xs">{m.modelName}</div>
                        <div className="text-[10px] text-slate-400 font-sans">{m.architecture} ({m.version})</div>
                      </td>
                      <td className="px-5 py-4">
                        <span className="px-2 py-0.5 rounded text-[10px] uppercase bg-slate-800 text-cyan-300 border border-slate-700">
                          {m.targetModality}
                        </span>
                      </td>
                      <td className="px-5 py-4 text-emerald-400 font-bold">{m.accuracy}%</td>
                      <td className="px-5 py-4 text-slate-200">{m.precision}%</td>
                      <td className="px-5 py-4 text-slate-200">{m.recall}%</td>
                      <td className="px-5 py-4 text-cyan-400 font-bold">{m.f1Score}%</td>
                      <td className="px-5 py-4 text-slate-400">
                        {m.falsePositiveRate}% / {m.falseNegativeRate}%
                      </td>
                      <td className="px-5 py-4 text-indigo-300 font-bold">{m.rocAuc}</td>
                      <td className="px-5 py-4 text-slate-400">{m.latencyMs} ms</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: High-Risk Queue */}
      {activeTab === 'high_risk' && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-rose-500/30 bg-rose-950/20 p-5">
            <h3 className="text-sm font-bold text-rose-300 flex items-center space-x-2">
              <AlertTriangle className="h-4 w-4 text-rose-400" />
              <span>High-Risk & Critical Flagged Queue</span>
            </h3>
            <p className="text-xs text-rose-200/70 mt-1">
              Media flagged with extreme deepfake confidence (&gt; 90%) or multiple severe anatomical and spectral anomalies.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {highRiskCases.map((c) => (
              <div
                key={c.id}
                onClick={() => onSelectCase(c)}
                className="p-4 rounded-xl border border-slate-800 bg-slate-900/80 hover:border-rose-500/50 cursor-pointer transition-all space-y-2 group"
              >
                <div className="flex items-center justify-between font-mono text-xs">
                  <span className="font-bold text-rose-400">{c.caseNumber}</span>
                  <span className="px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 text-[10px] font-bold">
                    {c.riskLevel} ({c.riskScore.toFixed(0)}%)
                  </span>
                </div>
                <h4 className="font-bold text-white text-sm truncate group-hover:text-cyan-300 transition-colors">
                  {c.fileName}
                </h4>
                <p className="text-xs text-slate-400 line-clamp-2">{c.conclusion}</p>
                <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 pt-2 border-t border-slate-800/80">
                  <span>Modality: {c.mediaType.toUpperCase()}</span>
                  <span className="text-cyan-400 font-semibold group-hover:underline">Inspect Case &rarr;</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: User & RBAC Management */}
      {activeTab === 'users' && (
        <div className="space-y-6">
          <div className="rounded-2xl border border-slate-800 bg-slate-900/60 overflow-hidden shadow-xl">
            <div className="p-5 border-b border-slate-800 flex justify-between items-center">
              <div>
                <h3 className="font-bold text-white text-base">User Directory & Role-Based Access Control (RBAC)</h3>
                <p className="text-xs text-slate-400">
                  Manage permissions for General Users, Forensic Investigators, and System Administrators.
                </p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 font-mono uppercase tracking-wider border-b border-slate-800">
                  <tr>
                    <th className="px-6 py-3.5">User</th>
                    <th className="px-6 py-3.5">Assigned Role</th>
                    <th className="px-6 py-3.5">Status</th>
                    <th className="px-6 py-3.5">Analyses Run</th>
                    <th className="px-6 py-3.5">Joined Date</th>
                    <th className="px-6 py-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-sans">
                  {users.map((u) => (
                    <tr key={u.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="px-6 py-4">
                        <div className="font-bold text-white">{u.name}</div>
                        <div className="text-slate-400 text-[11px] font-mono">{u.email}</div>
                      </td>
                      <td className="px-6 py-4">
                        <select
                          value={u.role}
                          onChange={(e) => onUpdateUserRole(u.id, e.target.value as UserRole)}
                          className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-xs text-cyan-300 font-medium focus:outline-none focus:border-cyan-500"
                        >
                          <option value="general_user">General User</option>
                          <option value="investigator">Forensic Investigator</option>
                          <option value="admin">System Administrator</option>
                        </select>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold ${
                          u.status === 'active'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            : 'bg-rose-950 text-rose-400 border border-rose-800'
                        }`}>
                          {u.status.toUpperCase()}
                        </span>
                      </td>
                      <td className="px-6 py-4 font-mono text-slate-300">{u.analysesCount || 0}</td>
                      <td className="px-6 py-4 text-slate-400 text-[11px]">
                        {new Date(u.createdAt).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <button
                          onClick={() => onToggleUserStatus(u.id)}
                          className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                            u.status === 'active'
                              ? 'bg-slate-800 hover:bg-rose-950 hover:text-rose-400 text-slate-300'
                              : 'bg-emerald-950 hover:bg-emerald-900 text-emerald-300'
                          }`}
                        >
                          {u.status === 'active' ? 'Suspend' : 'Activate'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
