export type MediaType = 'image' | 'video' | 'audio' | 'multimodal';

export type ClassificationType = 'REAL' | 'FAKE' | 'SUSPICIOUS' | 'INCONCLUSIVE';

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type UserRole = 'general_user' | 'investigator' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  status: 'active' | 'inactive';
  createdAt: string;
  analysesCount: number;
  phone?: string;
  avatar?: string;
}

export interface ForensicEvidenceItem {
  id: string;
  evidenceType: 
    | 'facial_inconsistency'
    | 'skin_texture_anomaly'
    | 'lighting_mismatch'
    | 'boundary_warping'
    | 'compression_anomaly'
    | 'metadata_anomaly'
    | 'temporal_flicker'
    | 'synthetic_voice_frequency'
    | 'audio_video_desync'
    | 'spectral_cutoff';
  title: string;
  score: number; // 0 - 100 risk
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  technicalDetails?: string;
}

export interface VideoFrameAnalysis {
  frameNumber: number;
  timestamp: string;
  prediction: ClassificationType;
  confidence: number;
  riskScore: number;
  anomalyType?: string;
  faceDetected: boolean;
  landmarksAligned: boolean;
  notes: string;
  thumbnailUrl?: string;
}

export type VideoFrameAnomaly = VideoFrameAnalysis;

export interface AudioForensicProfile {
  syntheticProbability: number;
  voiceConsistency: number;
  spectralAnalysisScore: number;
  harmonicToNoiseRatio: number;
  pitchAnomaliesDetected: boolean;
  frequencyCutoffKHz: number;
  spectralPoints: { freq: number; realMagnitude: number; sampleMagnitude: number }[];
}

export interface MetadataRecord {
  fileName: string;
  fileSize: number; // in bytes
  fileType: string;
  mimeType: string;
  sha256Hash: string;
  dimensions?: string;
  duration?: string;
  audioSampleRate?: string;
  softwareMetadata?: string;
  exifData?: Record<string, string>;
  isExifStripped: boolean;
  creationTimestamp?: string;
}

export interface ForensicCase {
  id: string; // e.g. DF-2026-4819
  caseNumber: string;
  userId: string;
  userName: string;
  mediaType: MediaType;
  fileName: string;
  fileSize: number;
  mediaUrl?: string;
  metadata: MetadataRecord;
  classification: ClassificationType;
  confidenceScore: number; // 0 - 100
  riskScore: number; // 0 - 100
  riskLevel: RiskLevel;
  modelName: string;
  modelVersion: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  createdAt: string;
  completedAt: string;
  
  // Modality specific scores
  faceAnalysisScore?: number;
  artifactAnalysisScore: number;
  metadataAnalysisScore: number;
  temporalAnalysisScore?: number;
  spectralAnalysisScore?: number;
  voiceConsistencyScore?: number;
  avSyncScore?: number;
  visualAnalysisScore?: number;

  keyFindings: string[];
  forensicEvidence: ForensicEvidenceItem[];
  videoFrames?: VideoFrameAnalysis[];
  audioProfile?: AudioForensicProfile;
  conclusion: string;
  disclaimer: string;
  reviewedByInvestigator?: boolean;

  // Strict Forensic Analysis Rubric Fields
  reasoning?: string;
  subjectAuthenticity?: string;
  backgroundAuthenticity?: string;
  manipulationDetected?: boolean;
  manipulationType?: string;
  backgroundIndicators?: string[];
  aiGenerationIndicators?: string[];
  faceManipulationIndicators?: string[];
  compositeIndicators?: string[];
  metadataFindings?: string[];
  forensicFindings?: string[];
  keyEvidence?: string[];
  limitations?: string[];
}

export interface BenchmarkSample {
  id: string;
  title: string;
  category: string;
  mediaType: MediaType;
  expectedClassification: ClassificationType;
  description: string;
  manipulationType: string;
  thumbnailUrl: string;
  fileUrl?: string;
  fileSize: number;
  dimensions?: string;
  duration?: string;
}

export interface ModelPerformanceMetric {
  id: string;
  modelName: string;
  architecture: string;
  targetModality: MediaType | 'all';
  version: string;
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  falsePositiveRate: number;
  falseNegativeRate: number;
  rocAuc: number;
  latencyMs: number;
  evaluationSamples: number;
  status: 'active' | 'evaluating' | 'deprecated';
}

export interface AdminSystemStats {
  totalUsers: number;
  activeUsers: number;
  totalAnalyses: number;
  realCount: number;
  fakeCount: number;
  suspiciousCount: number;
  inconclusiveCount: number;
  analysesByType: {
    image: number;
    video: number;
    audio: number;
    multimodal: number;
  };
  timelineData: {
    date: string;
    total: number;
    real: number;
    fake: number;
    suspicious: number;
  }[];
}
