import { ForensicCase, ModelPerformanceMetric, User } from '../types';

export const INITIAL_USERS: User[] = [
  {
    id: 'usr-001',
    name: 'Dr. Sarah Lin, Forensic Lead',
    email: 'sarah.lin@forensics.agency.gov',
    role: 'investigator',
    status: 'active',
    createdAt: '2026-01-15T08:00:00Z',
    analysesCount: 48,
    phone: '+1 (555) 234-5678',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=120&auto=format&fit=crop&q=80'
  },
  {
    id: 'usr-002',
    name: 'Alex Vance (System Admin)',
    email: 'alex.vance@deepfakewatch.internal',
    role: 'admin',
    status: 'active',
    createdAt: '2025-11-10T10:30:00Z',
    analysesCount: 112,
    phone: '+1 (555) 987-6543',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80'
  },
  {
    id: 'usr-003',
    name: 'Marcus Brody (Journalist)',
    email: 'm.brody@globalnews.org',
    role: 'general_user',
    status: 'active',
    createdAt: '2026-02-01T14:20:00Z',
    analysesCount: 14,
    phone: '+1 (555) 456-7890'
  },
  {
    id: 'usr-004',
    name: 'Elena Rostova',
    email: 'elena.rostova@cyberdefense.eu',
    role: 'investigator',
    status: 'active',
    createdAt: '2026-02-14T09:15:00Z',
    analysesCount: 29
  },
  {
    id: 'usr-005',
    name: 'David Chen',
    email: 'dchen@techverification.io',
    role: 'general_user',
    status: 'inactive',
    createdAt: '2026-01-20T11:45:00Z',
    analysesCount: 6
  }
];

export const MODEL_PERFORMANCE_METRICS: ModelPerformanceMetric[] = [
  {
    id: 'mod-001',
    modelName: 'DeepForensic Vision 3.7',
    architecture: 'Multimodal Vision Transformer + ResNet-FF++',
    targetModality: 'image',
    version: 'v3.7.2',
    accuracy: 97.4,
    precision: 96.8,
    recall: 98.1,
    f1Score: 97.4,
    falsePositiveRate: 1.8,
    falseNegativeRate: 1.9,
    rocAuc: 0.992,
    latencyMs: 380,
    evaluationSamples: 14200,
    status: 'active'
  },
  {
    id: 'mod-002',
    modelName: 'TemporalConsistency-Net 4D',
    architecture: '3D ResNet + Bidirectional GRU Optical Flow',
    targetModality: 'video',
    version: 'v4.1.0',
    accuracy: 95.8,
    precision: 94.9,
    recall: 96.5,
    f1Score: 95.7,
    falsePositiveRate: 2.6,
    falseNegativeRate: 3.5,
    rocAuc: 0.984,
    latencyMs: 1420,
    evaluationSamples: 8500,
    status: 'active'
  },
  {
    id: 'mod-003',
    modelName: 'SpectralGuard Audio Forensics',
    architecture: 'Wav2Vec 2.0 + Mel-Spectrogram Residual CNN',
    targetModality: 'audio',
    version: 'v2.8.4',
    accuracy: 96.2,
    precision: 95.5,
    recall: 97.0,
    f1Score: 96.2,
    falsePositiveRate: 2.1,
    falseNegativeRate: 3.0,
    rocAuc: 0.988,
    latencyMs: 290,
    evaluationSamples: 9100,
    status: 'active'
  },
  {
    id: 'mod-004',
    modelName: 'SyncNet AV Cross-Modal Fusion',
    architecture: 'Audio-Visual Dual Attention Transformer',
    targetModality: 'multimodal',
    version: 'v3.3.1',
    accuracy: 98.2,
    precision: 97.9,
    recall: 98.5,
    f1Score: 98.2,
    falsePositiveRate: 1.2,
    falseNegativeRate: 1.5,
    rocAuc: 0.996,
    latencyMs: 1950,
    evaluationSamples: 6400,
    status: 'active'
  }
];

export const INITIAL_FORENSIC_CASES: ForensicCase[] = [
  {
    id: 'case-df-001',
    caseNumber: 'DF-2026-001',
    userId: 'usr-001',
    userName: 'Dr. Sarah Lin',
    mediaType: 'image',
    fileName: 'executive_statement_photo.jpg',
    fileSize: 2450000,
    mediaUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80',
    metadata: {
      fileName: 'executive_statement_photo.jpg',
      fileSize: 2450000,
      fileType: 'image/jpeg',
      mimeType: 'image/jpeg',
      sha256Hash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      dimensions: '2048 x 1365 px',
      isExifStripped: true,
      softwareMetadata: 'Adobe Photoshop / Generative Fill Model v2.4 (Stripped C2PA Manifest)',
      creationTimestamp: '2026-09-01T14:12:00Z'
    },
    classification: 'FAKE',
    confidenceScore: 94.6,
    riskScore: 92.0,
    riskLevel: 'HIGH',
    modelName: 'DeepForensic Vision 3.7 + Error Level Analysis',
    modelVersion: 'v3.7.2-forensics',
    status: 'completed',
    createdAt: '2026-09-01T14:15:30Z',
    completedAt: '2026-09-01T14:15:34Z',
    faceAnalysisScore: 96.2,
    artifactAnalysisScore: 91.8,
    metadataAnalysisScore: 84.5,
    keyFindings: [
      'Iris reflection asymmetry indicates non-physical light sources.',
      'JPEG quantization table mismatch between facial region (Q=72) and background (Q=95).',
      'High-frequency Fourier transform reveals distinct diffusion checkerboard grid pattern in hair boundary.'
    ],
    forensicEvidence: [
      {
        id: 'ev-01',
        evidenceType: 'facial_inconsistency',
        title: 'Corneal Specular Reflection Anomaly',
        score: 96,
        severity: 'critical',
        description: 'Left eye highlights correspond to point source at 45°, whereas right eye highlights show diffused ambient lighting with no matching vector.',
        technicalDetails: 'Ray-vector divergence: 38.4° (normal threshold < 4.0°)'
      },
      {
        id: 'ev-02',
        evidenceType: 'compression_anomaly',
        title: 'Error Level Analysis (ELA) Splicing Signature',
        score: 89,
        severity: 'high',
        description: 'Facial bounding box exhibits significantly higher compression error residuals compared to surrounding collar and backdrop.',
        technicalDetails: 'Residual Delta: +24.8 dB in 8x8 DCT high-frequency coefficients.'
      },
      {
        id: 'ev-03',
        evidenceType: 'metadata_anomaly',
        title: 'Stripped Camera Sensor Calibration & Serial',
        score: 78,
        severity: 'medium',
        description: 'EXIF payload is truncated with missing MakerNotes and synthetic quantization markers.'
      }
    ],
    conclusion: 'Forensic evaluation demonstrates conclusive evidence of synthetic facial generation and image splicing. The image is classified as a DEEPFAKE with 94.6% model confidence.',
    disclaimer: 'This automated forensic report is generated by Deepfake Detection System. Results should be corroborated by certified digital forensic examiners before formal legal proceedings.',
    reviewedByInvestigator: true
  },
  {
    id: 'case-df-002',
    caseNumber: 'DF-2026-002',
    userId: 'usr-003',
    userName: 'Marcus Brody',
    mediaType: 'video',
    fileName: 'broadcast_interview_leak.mp4',
    fileSize: 18900000,
    mediaUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=800&auto=format&fit=crop&q=80',
    metadata: {
      fileName: 'broadcast_interview_leak.mp4',
      fileSize: 18900000,
      fileType: 'video/mp4',
      mimeType: 'video/mp4',
      sha256Hash: 'a1b2c3d4e5f60718293a4b5c6d7e8f90123456789abcdef0123456789abcdef0',
      dimensions: '1920 x 1080 @ 29.97 fps',
      duration: '00:15',
      isExifStripped: false,
      creationTimestamp: '2026-09-01T12:00:00Z'
    },
    classification: 'SUSPICIOUS',
    confidenceScore: 86.4,
    riskScore: 79.5,
    riskLevel: 'HIGH',
    modelName: 'TemporalConsistency-Net 4D + FaceWarp Detector',
    modelVersion: 'v4.1.0',
    status: 'completed',
    createdAt: '2026-09-01T12:05:10Z',
    completedAt: '2026-09-01T12:05:18Z',
    faceAnalysisScore: 88.0,
    artifactAnalysisScore: 82.5,
    metadataAnalysisScore: 68.0,
    temporalAnalysisScore: 91.2,
    keyFindings: [
      'Temporal instability detected between Frame #112 and Frame #148.',
      'Unnatural blinking rate (0 blinks in 15 seconds) with rigid eyelid boundary.',
      'Mouth-region motion vector discontinuity relative to jaw bone structure.'
    ],
    videoFrames: [
      {
        frameNumber: 42,
        timestamp: '00:01.40',
        prediction: 'REAL',
        confidence: 91.0,
        riskScore: 12.0,
        faceDetected: true,
        landmarksAligned: true,
        notes: 'Natural frame texture and lighting consistency.'
      },
      {
        frameNumber: 118,
        timestamp: '00:03.93',
        prediction: 'FAKE',
        confidence: 89.4,
        riskScore: 88.0,
        anomalyType: 'Inter-frame edge warping & blurring',
        faceDetected: true,
        landmarksAligned: false,
        notes: 'Boundary flicker around lower jaw; high optical flow shear.'
      },
      {
        frameNumber: 142,
        timestamp: '00:04.73',
        prediction: 'FAKE',
        confidence: 93.1,
        riskScore: 94.0,
        anomalyType: 'Wav2Lip Reenactment artifact',
        faceDetected: true,
        landmarksAligned: false,
        notes: 'Phoneme shape mismatch with dental occlusion rendering.'
      },
      {
        frameNumber: 280,
        timestamp: '00:09.34',
        prediction: 'SUSPICIOUS',
        confidence: 76.5,
        riskScore: 71.0,
        anomalyType: 'Motion blur compensation anomaly',
        faceDetected: true,
        landmarksAligned: true,
        notes: 'Interpolated facial frame with loss of skin pore sharpness.'
      }
    ],
    forensicEvidence: [
      {
        id: 'ev-11',
        evidenceType: 'temporal_flicker',
        title: 'Inter-Frame Optical Flow Variance',
        score: 91,
        severity: 'critical',
        description: 'Significant temporal jitter along 68 facial landmark coordinates across consecutive video frames.',
        technicalDetails: 'Velocity variance σ² = 14.2 px² (natural tolerance < 2.5 px²)'
      },
      {
        id: 'ev-12',
        evidenceType: 'facial_inconsistency',
        title: 'Blink Frequency Anomaly',
        score: 84,
        severity: 'high',
        description: 'Subject displays zero spontaneous eyelid closures over a continuous 15-second interval.',
        technicalDetails: 'Observed Blink Rate: 0.0 bpm (Standard human baseline: 12-20 bpm)'
      }
    ],
    conclusion: 'Video analysis demonstrates high temporal and facial manipulation risk. Frame sequence 112-148 contains evident neural lip-sync manipulation artifacts.',
    disclaimer: 'This automated forensic report is generated by Deepfake Detection System. Results should be corroborated by certified digital forensic examiners.',
    reviewedByInvestigator: false
  },
  {
    id: 'case-df-003',
    caseNumber: 'DF-2026-003',
    userId: 'usr-002',
    userName: 'Alex Vance',
    mediaType: 'audio',
    fileName: 'ceo_authorization_voicemail.wav',
    fileSize: 3800000,
    metadata: {
      fileName: 'ceo_authorization_voicemail.wav',
      fileSize: 3800000,
      fileType: 'audio/wav',
      mimeType: 'audio/wav',
      sha256Hash: 'f4e3d2c1b0a987654321fedcba0987654321abcdef0123456789fedcba098765',
      duration: '00:19',
      audioSampleRate: '44,100 Hz / 16-bit PCM Mono',
      isExifStripped: false,
      creationTimestamp: '2026-08-30T18:30:00Z'
    },
    classification: 'FAKE',
    confidenceScore: 95.8,
    riskScore: 94.2,
    riskLevel: 'CRITICAL',
    modelName: 'SpectralGuard Audio Forensics + Waveform Classifier',
    modelVersion: 'v2.8.4',
    status: 'completed',
    createdAt: '2026-08-30T18:40:00Z',
    completedAt: '2026-08-30T18:40:03Z',
    spectralAnalysisScore: 96.5,
    voiceConsistencyScore: 93.0,
    artifactAnalysisScore: 94.0,
    metadataAnalysisScore: 72.0,
    audioProfile: {
      syntheticProbability: 95.8,
      voiceConsistency: 93.0,
      spectralAnalysisScore: 96.5,
      harmonicToNoiseRatio: 18.2,
      pitchAnomaliesDetected: true,
      frequencyCutoffKHz: 16.0,
      spectralPoints: [
        { freq: 100, realMagnitude: 45, sampleMagnitude: 44 },
        { freq: 500, realMagnitude: 68, sampleMagnitude: 72 },
        { freq: 1000, realMagnitude: 60, sampleMagnitude: 62 },
        { freq: 2500, realMagnitude: 52, sampleMagnitude: 51 },
        { freq: 5000, realMagnitude: 40, sampleMagnitude: 38 },
        { freq: 8000, realMagnitude: 32, sampleMagnitude: 30 },
        { freq: 12000, realMagnitude: 24, sampleMagnitude: 21 },
        { freq: 16000, realMagnitude: 16, sampleMagnitude: 3 }, // Sudden synthetic cutoff
        { freq: 20000, realMagnitude: 8, sampleMagnitude: 0 }
      ]
    },
    keyFindings: [
      'Unnatural brick-wall spectral cutoff at exactly 16.0 kHz characteristic of neural vocoders.',
      'Absence of physiologic breath intakes and micro-laryngeal tremors.',
      'Robotic constant pitch inflection across question clauses.'
    ],
    forensicEvidence: [
      {
        id: 'ev-21',
        evidenceType: 'spectral_cutoff',
        title: 'Neural Vocoder Nyquist Frequency Cutoff (16kHz)',
        score: 98,
        severity: 'critical',
        description: 'Frequency power spectrum drops immediately to -80 dB above 16 kHz without natural atmospheric dissipation.',
        technicalDetails: 'Slope: -45 dB/octave above 16.0 kHz band'
      },
      {
        id: 'ev-22',
        evidenceType: 'synthetic_voice_frequency',
        title: 'Phonetic Phase Discontinuity',
        score: 92,
        severity: 'high',
        description: 'Formant transitions exhibit mathematical smoothness typical of autoregressive text-to-speech architectures.',
        technicalDetails: 'Formant F1/F2 trajectory smoothness score: 0.985 (Human speech range: 0.62-0.78)'
      }
    ],
    conclusion: 'Audio sample exhibits hallmark signatures of zero-shot neural voice cloning (TTS/Voice Conversion). The recording is classified as a SYNTHETIC DEEPFAKE with 95.8% confidence.',
    disclaimer: 'This automated forensic report is generated by Deepfake Detection System. Results should be corroborated by certified forensic audio engineers.',
    reviewedByInvestigator: true
  },
  {
    id: 'case-df-004',
    caseNumber: 'DF-2026-004',
    userId: 'usr-001',
    userName: 'Dr. Sarah Lin',
    mediaType: 'image',
    fileName: 'press_conference_raw_dslr.jpg',
    fileSize: 4890000,
    mediaUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&auto=format&fit=crop&q=80',
    metadata: {
      fileName: 'press_conference_raw_dslr.jpg',
      fileSize: 4890000,
      fileType: 'image/jpeg',
      mimeType: 'image/jpeg',
      sha256Hash: '7b8c9d0e1f2a3b4c5d6e7f8091a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f901',
      dimensions: '3840 x 2560 px',
      isExifStripped: false,
      softwareMetadata: 'Sony Alpha ILCE-7RM4 v1.20',
      creationTimestamp: '2026-08-28T11:15:00Z',
      exifData: {
        'Camera Model': 'Sony A7R IV',
        'Lens': 'FE 85mm F1.4 GM',
        'ISO': '200',
        'Shutter Speed': '1/500 sec',
        'Aperture': 'f/2.0',
        'Color Space': 'sRGB'
      }
    },
    classification: 'REAL',
    confidenceScore: 98.2,
    riskScore: 4.5,
    riskLevel: 'LOW',
    modelName: 'DeepForensic Vision 3.7 + Sensor PRNU Verifier',
    modelVersion: 'v3.7.2-forensics',
    status: 'completed',
    createdAt: '2026-08-28T11:20:00Z',
    completedAt: '2026-08-28T11:20:04Z',
    faceAnalysisScore: 98.8,
    artifactAnalysisScore: 97.5,
    metadataAnalysisScore: 96.0,
    keyFindings: [
      'Photo-Response Non-Uniformity (PRNU) noise pattern is uniformly continuous across the entire sensor grid.',
      'Consistent natural skin pore distribution and optical depth of field blur falloff.',
      'Unmodified Sony RAW-derived EXIF metadata with authentic camera sensor serial validation.'
    ],
    forensicEvidence: [
      {
        id: 'ev-31',
        evidenceType: 'skin_texture_anomaly',
        title: 'Sub-Surface Light Scattering Verified',
        score: 4,
        severity: 'low',
        description: 'Epidermal light dispersion conforms to biological Rayleigh scattering physics with no neural smoothing.',
        technicalDetails: 'Red/Green channel diffusion ratio: 1.42 (Within standard human dermal specs)'
      }
    ],
    conclusion: 'Forensic tests reveal no indicators of digital tampering, face-swapping, or generative AI synthesis. The media is classified as AUTHENTIC / REAL with 98.2% confidence.',
    disclaimer: 'This automated forensic report is generated by Deepfake Detection System. Results should be corroborated by certified digital forensic examiners.',
    reviewedByInvestigator: true
  },
  {
    id: 'case-df-005',
    caseNumber: 'DF-2026-005',
    userId: 'usr-004',
    userName: 'Elena Rostova',
    mediaType: 'multimodal',
    fileName: 'multimodal_diplomatic_briefing.mp4',
    fileSize: 42100000,
    mediaUrl: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=800&auto=format&fit=crop&q=80',
    metadata: {
      fileName: 'multimodal_diplomatic_briefing.mp4',
      fileSize: 42100000,
      fileType: 'video/mp4',
      mimeType: 'video/mp4',
      sha256Hash: 'c9b8a7f6e5d4c3b2a10987654321fedcba9876543210fedcba9876543210fedc',
      dimensions: '1920 x 1080 @ 30 fps',
      duration: '00:24',
      isExifStripped: false,
      creationTimestamp: '2026-08-25T09:40:00Z'
    },
    classification: 'FAKE',
    confidenceScore: 96.7,
    riskScore: 93.8,
    riskLevel: 'CRITICAL',
    modelName: 'SyncNet AV Cross-Modal Fusion + Multimodal Transformer',
    modelVersion: 'v3.3.1',
    status: 'completed',
    createdAt: '2026-08-25T09:45:00Z',
    completedAt: '2026-08-25T09:45:12Z',
    visualAnalysisScore: 92.5,
    faceAnalysisScore: 94.0,
    spectralAnalysisScore: 88.0,
    voiceConsistencyScore: 86.0,
    temporalAnalysisScore: 89.5,
    metadataAnalysisScore: 74.0,
    avSyncScore: 95.0,
    artifactAnalysisScore: 91.0,
    keyFindings: [
      'Pronounced Audio-Visual desynchronization (+180ms voice lead ahead of viseme formation).',
      'Synthetic vocal timbre detected via harmonic phase irregularities.',
      'Facial reenactment seam visible at jaw-neck junction during sudden lateral head rotations.'
    ],
    videoFrames: [
      {
        frameNumber: 15,
        timestamp: '00:00.50',
        prediction: 'REAL',
        confidence: 88.0,
        riskScore: 18.0,
        faceDetected: true,
        landmarksAligned: true,
        notes: 'Introductory frame without speech activity.'
      },
      {
        frameNumber: 94,
        timestamp: '00:03.13',
        prediction: 'FAKE',
        confidence: 96.0,
        riskScore: 95.0,
        anomalyType: 'Viseme / Phoneme Desync',
        faceDetected: true,
        landmarksAligned: false,
        notes: 'Bilabial plosive /p/ pronounced in audio track 180ms before lips close.'
      },
      {
        frameNumber: 180,
        timestamp: '00:06.00',
        prediction: 'FAKE',
        confidence: 94.2,
        riskScore: 92.0,
        anomalyType: 'Facial Mask Inpainting Artifact',
        faceDetected: true,
        landmarksAligned: false,
        notes: 'Color gamut discontinuity along mandible contour.'
      }
    ],
    audioProfile: {
      syntheticProbability: 91.2,
      voiceConsistency: 86.0,
      spectralAnalysisScore: 88.0,
      harmonicToNoiseRatio: 16.5,
      pitchAnomaliesDetected: true,
      frequencyCutoffKHz: 18.5,
      spectralPoints: [
        { freq: 100, realMagnitude: 50, sampleMagnitude: 48 },
        { freq: 500, realMagnitude: 75, sampleMagnitude: 78 },
        { freq: 1000, realMagnitude: 65, sampleMagnitude: 70 },
        { freq: 2500, realMagnitude: 55, sampleMagnitude: 54 },
        { freq: 5000, realMagnitude: 42, sampleMagnitude: 39 },
        { freq: 8000, realMagnitude: 35, sampleMagnitude: 31 },
        { freq: 12000, realMagnitude: 28, sampleMagnitude: 22 },
        { freq: 16000, realMagnitude: 20, sampleMagnitude: 12 },
        { freq: 20000, realMagnitude: 12, sampleMagnitude: 2 }
      ]
    },
    forensicEvidence: [
      {
        id: 'ev-41',
        evidenceType: 'audio_video_desync',
        title: 'Cross-Modal Viseme-to-Phoneme Lag (+180ms)',
        score: 95,
        severity: 'critical',
        description: 'Audio speech track is out of sync with muscular lip motions, violating biometric speech motor control constraints.',
        technicalDetails: 'SyncNet Offset: +180.2 ms (Human tolerance: ±40 ms)'
      },
      {
        id: 'ev-42',
        evidenceType: 'facial_inconsistency',
        title: 'Deepfake Re-enactment Boundary Mask Seam',
        score: 91,
        severity: 'high',
        description: 'Poisson blending residuals detected along the perimeter of the face-swapped overlay.',
        technicalDetails: 'Gradient mismatch along jaw line: ΔG = 0.34'
      }
    ],
    conclusion: 'Multimodal evidence fusion establishes that this media is an orchestrated Deepfake combining synthetic neural voice with an AI-generated face replacement. Multimodal Risk is 93.8%.',
    disclaimer: 'This automated forensic report is generated by Deepfake Detection System. Results should be corroborated by certified digital forensic examiners.',
    reviewedByInvestigator: true
  }
];
