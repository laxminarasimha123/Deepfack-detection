import { BenchmarkSample } from '../types';

export const SAMPLE_BENCHMARKS: BenchmarkSample[] = [
  {
    id: 'sample-img-deepfake-01',
    title: 'AI Synthesized Portrait (Diffusion Gen)',
    category: 'Facial Synthesis / GAN',
    mediaType: 'image',
    expectedClassification: 'FAKE',
    manipulationType: 'Latent Diffusion + FaceSwap (Boundary blurring & iris asymmetry)',
    thumbnailUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=600&auto=format&fit=crop&q=80',
    fileSize: 1845200,
    dimensions: '1920x1080',
    description: 'Generated synthetic portrait showing classic high-frequency background blending artifacts, mismatched earlobe geometry, and unnatural corneal reflections.'
  },
  {
    id: 'sample-img-real-01',
    title: 'Authentic Photojournalism Portrait',
    category: 'Verified Authentic',
    mediaType: 'image',
    expectedClassification: 'REAL',
    manipulationType: 'None (Raw Sensor Capture with intact Bayer Pattern)',
    thumbnailUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&auto=format&fit=crop&q=80',
    fileSize: 3420190,
    dimensions: '3840x2160',
    description: 'Genuine camera sensor capture featuring consistent natural skin pores, uniform optical lens blur falloff, and valid EXIF metadata headers.'
  },
  {
    id: 'sample-img-suspicious-01',
    title: 'Facial Retouching & Warped Jawline',
    category: 'Partial Manipulation',
    mediaType: 'image',
    expectedClassification: 'SUSPICIOUS',
    manipulationType: 'Digital Splicing & Neural Skin Smoothing',
    thumbnailUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=600&auto=format&fit=crop&q=80',
    fileSize: 2104000,
    dimensions: '2048x1536',
    description: 'Localized neural inpainting around the perimeter of the jawline with subtle JPEG compression block disparity.'
  },
  {
    id: 'sample-vid-deepfake-01',
    title: 'Video Face-Swap & Speech Lip-Sync',
    category: 'Video Deepfake (Wav2Lip + SimSwap)',
    mediaType: 'video',
    expectedClassification: 'FAKE',
    manipulationType: 'Inter-frame warping & mouth boundary blurring',
    thumbnailUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=600&auto=format&fit=crop&q=80',
    fileSize: 14850000,
    duration: '00:14',
    dimensions: '1920x1080',
    description: 'Synthesized video showing micro-flickering across consecutive frames (Frame 42 to 78) and optical flow shear along the chin contour.'
  },
  {
    id: 'sample-vid-real-01',
    title: 'Authentic Press Briefing Clip',
    category: 'Verified Broadcast',
    mediaType: 'video',
    expectedClassification: 'REAL',
    manipulationType: 'None (Studio SMPTE timecoded stream)',
    thumbnailUrl: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=600&auto=format&fit=crop&q=80',
    fileSize: 24100000,
    duration: '00:22',
    dimensions: '1920x1080',
    description: 'Continuous temporal consistency, natural eye saccades and blink intervals (15 blinks/min), and synchronized audio timestamps.'
  },
  {
    id: 'sample-aud-cloned-01',
    title: 'Neural Cloned Voice Audio (Zero-Shot)',
    category: 'Synthetic Speech / TTS',
    mediaType: 'audio',
    expectedClassification: 'FAKE',
    manipulationType: 'Neural Vocoder Synthesis (Missing breath intake)',
    thumbnailUrl: 'https://images.unsplash.com/photo-1590602847861-f357a9332bbc?w=600&auto=format&fit=crop&q=80',
    fileSize: 4200000,
    duration: '00:18',
    description: 'Audio speech sample showing unnatural high-frequency cutoff above 18kHz, absent micro-tremors, and robotic phonetic transitions.'
  },
  {
    id: 'sample-multimodal-01',
    title: 'Multimodal Political Address Deepfake',
    category: 'Full Audio-Visual Deepfake',
    mediaType: 'multimodal',
    expectedClassification: 'FAKE',
    manipulationType: 'Voice Clone + Re-enactment + Lip-Sync Fusion',
    thumbnailUrl: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=600&auto=format&fit=crop&q=80',
    fileSize: 32500000,
    duration: '00:28',
    dimensions: '1920x1080',
    description: 'High-risk multimodal deepfake combining synthesized voice with reenacted facial animation. Cross-modal lip-sync error detected with +180ms delay.'
  }
];
