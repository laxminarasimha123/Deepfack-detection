import { jsPDF } from 'jspdf';
import { ForensicCase } from '../types';

export function exportForensicReportPDF(reportCase: ForensicCase) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 18;

  // Header Banner
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(0, 0, pageWidth, 26, 'F');

  doc.setTextColor(56, 189, 248); // sky-400
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('NATIONAL DIGITAL FORENSICS & AI DETECTION SYSTEM', 14, 11);

  doc.setTextColor(148, 163, 184); // slate-400
  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.text('OFFICIAL MEDIA AUTHENTICITY & MULTIMODAL FORENSIC REPORT', 14, 18);
  doc.text(`CONFIDENTIAL | CASE REF: ${reportCase.caseNumber}`, pageWidth - 14, 18, { align: 'right' });

  y = 34;

  // Case Metadata Box
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.rect(14, y, pageWidth - 28, 28, 'FD');

  doc.setTextColor(15, 23, 42);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text('1. CASE INFORMATION', 18, y + 6);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.text(`Case ID: ${reportCase.caseNumber}`, 18, y + 12);
  doc.text(`File Name: ${reportCase.fileName}`, 18, y + 17);
  doc.text(`File Type: ${reportCase.metadata.fileType.toUpperCase()}`, 18, y + 22);

  doc.text(`File Size: ${(reportCase.fileSize / 1024 / 1024).toFixed(2)} MB`, 95, y + 12);
  doc.text(`Upload Date: ${new Date(reportCase.createdAt).toLocaleString()}`, 95, y + 17);
  doc.text(`SHA-256: ${reportCase.metadata.sha256Hash.substring(0, 28)}...`, 95, y + 22);

  y += 34;

  // Overall Classification Banner
  let statusColor: [number, number, number] = [220, 38, 38]; // Red (Fake)
  if (reportCase.classification === 'REAL') {
    statusColor = [22, 163, 74]; // Green
  } else if (reportCase.classification === 'SUSPICIOUS') {
    statusColor = [217, 119, 6]; // Orange/Amber
  } else if (reportCase.classification === 'INCONCLUSIVE') {
    statusColor = [100, 116, 139]; // Slate
  }

  doc.setFillColor(...statusColor);
  doc.rect(14, y, pageWidth - 28, 14, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text(`OVERALL CLASSIFICATION: ${reportCase.classification}`, 18, y + 9);
  doc.text(`CONFIDENCE: ${reportCase.confidenceScore.toFixed(1)}% | RISK: ${reportCase.riskScore.toFixed(1)}% (${reportCase.riskLevel})`, pageWidth - 18, y + 9, { align: 'right' });

  y += 20;

  // Section 2: AI Model Specifications
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text('2. FORENSIC AI DETECTION PIPELINE', 14, y);
  y += 5;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.text(`Primary Model: ${reportCase.modelName}`, 14, y);
  doc.text(`Model Version: ${reportCase.modelVersion}`, 110, y);
  y += 4;
  doc.text(`Analysis Completed: ${new Date(reportCase.completedAt).toLocaleString()}`, 14, y);
  doc.text(`Investigator Review: ${reportCase.reviewedByInvestigator ? 'VERIFIED' : 'PENDING'}`, 110, y);
  y += 7;

  // Section 3: Forensic Modality Breakdown Scores
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('3. MODALITY RISK SCORES', 14, y);
  y += 6;

  const metrics = [
    ...(reportCase.faceAnalysisScore !== undefined ? [{ label: 'Facial Analysis', score: reportCase.faceAnalysisScore }] : []),
    { label: 'Artifact Analysis', score: reportCase.artifactAnalysisScore },
    { label: 'Metadata Integrity', score: reportCase.metadataAnalysisScore },
    ...(reportCase.temporalAnalysisScore ? [{ label: 'Temporal Consistency', score: reportCase.temporalAnalysisScore }] : []),
    ...(reportCase.spectralAnalysisScore ? [{ label: 'Spectral Voice Anomaly', score: reportCase.spectralAnalysisScore }] : []),
    ...(reportCase.avSyncScore ? [{ label: 'Audio-Visual Sync', score: reportCase.avSyncScore }] : []),
  ];

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  let colX = 14;
  metrics.forEach((m, idx) => {
    doc.setDrawColor(203, 213, 225);
    doc.setFillColor(241, 245, 249);
    doc.rect(colX, y, 55, 10, 'FD');
    doc.setTextColor(30, 41, 59);
    doc.text(`${m.label}:`, colX + 3, y + 6.5);
    doc.setFont('helvetica', 'bold');
    doc.text(`${m.score}%`, colX + 48, y + 6.5, { align: 'right' });
    doc.setFont('helvetica', 'normal');

    colX += 58;
    if ((idx + 1) % 3 === 0) {
      colX = 14;
      y += 13;
    }
  });

  if (metrics.length % 3 !== 0) {
    y += 14;
  } else {
    y += 4;
  }

  // Section 4: Forensic Evidence & Findings
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text('4. FORENSIC EVIDENCE & SEPARATION ANALYSIS', 14, y);
  y += 5;

  if (reportCase.subjectAuthenticity || reportCase.backgroundAuthenticity) {
    doc.setFontSize(7.5);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text(`Subject: ${reportCase.subjectAuthenticity || 'N/A'}`, 16, y);
    y += 4;
    doc.text(`Background: ${reportCase.backgroundAuthenticity || 'N/A'}`, 16, y);
    y += 4.5;
  }

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  (reportCase.forensicEvidence || []).slice(0, 3).forEach((ev) => {
    doc.setTextColor(15, 23, 42);
    doc.setFont('helvetica', 'bold');
    doc.text(`• [${ev.severity.toUpperCase()}] ${ev.title} (Score: ${ev.score}/100)`, 16, y);
    y += 4;
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(71, 85, 105);
    const descLines = doc.splitTextToSize(ev.description, pageWidth - 36);
    doc.text(descLines, 20, y);
    y += descLines.length * 3.8 + 2;
  });

  if (reportCase.aiGenerationIndicators && reportCase.aiGenerationIndicators.length > 0) {
    doc.setTextColor(190, 24, 93);
    doc.setFont('helvetica', 'bold');
    doc.text(`AI Indicators: ${reportCase.aiGenerationIndicators.slice(0, 2).join('; ')}`, 16, y);
    y += 4.5;
  }

  y += 2;

  // Section 5: Conclusion
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text('5. FORENSIC CONCLUSION', 14, y);
  y += 5;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(30, 41, 59);
  const conclusionLines = doc.splitTextToSize(reportCase.conclusion, pageWidth - 28);
  doc.text(conclusionLines, 14, y);
  y += conclusionLines.length * 4 + 4;

  // Section 6: Legal & Forensic Disclaimer
  doc.setFillColor(241, 245, 249);
  doc.rect(14, y, pageWidth - 28, 16, 'F');
  doc.setTextColor(100, 116, 139);
  doc.setFontSize(7);
  doc.setFont('helvetica', 'italic');
  const disclaimerText =
    'DISCLAIMER: Automated detection is an analytical assessment powered by deep learning and multimodal heuristics. It should not automatically be treated as definitive legal proof without certified human examiner review.';
  const discLines = doc.splitTextToSize(disclaimerText, pageWidth - 34);
  doc.text(discLines, 17, y + 5);

  // Footer
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(148, 163, 184);
  doc.text(`Generated on ${new Date().toUTCString()} | System UID: DFS-2026-X88`, 14, 288);
  doc.text('Page 1 of 1', pageWidth - 14, 288, { align: 'right' });

  doc.save(`Forensic_Report_${reportCase.caseNumber}.pdf`);
}

export function exportForensicReportJSON(reportCase: ForensicCase) {
  const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(
    JSON.stringify(reportCase, null, 2)
  )}`;
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', jsonString);
  downloadAnchor.setAttribute('download', `Forensic_Report_${reportCase.caseNumber}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}

export function exportCasesCSV(cases: ForensicCase[]) {
  const headers = ['Case ID', 'File Name', 'Media Type', 'Classification', 'Confidence (%)', 'Risk (%)', 'Risk Level', 'Model', 'Date'];
  const rows = cases.map((c) => [
    c.caseNumber,
    `"${c.fileName.replace(/"/g, '""')}"`,
    c.mediaType,
    c.classification,
    c.confidenceScore.toFixed(1),
    c.riskScore.toFixed(1),
    c.riskLevel,
    `"${c.modelName.replace(/"/g, '""')}"`,
    new Date(c.createdAt).toLocaleDateString(),
  ]);

  const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', `Forensic_Detection_History_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  link.remove();
}
